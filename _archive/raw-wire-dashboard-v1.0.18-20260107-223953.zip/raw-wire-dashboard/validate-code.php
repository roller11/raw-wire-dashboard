#!/usr/bin/env php
<?php
/**
 * RawWire Dashboard - Code Validation Script
 * 
 * Validates plugin code without requiring WordPress installation.
 * Checks:
 * - PHP syntax
 * - Class definitions
 * - REST endpoint registrations
 * - Database schema
 * - Simulator data templates
 *
 * @package    RawWire_Dashboard
 * @since      1.0.13
 */

define('ANSI_GREEN', "\033[32m");
define('ANSI_RED', "\033[31m");
define('ANSI_YELLOW', "\033[33m");
define('ANSI_BLUE', "\033[34m");
define('ANSI_CYAN', "\033[36m");
define('ANSI_RESET', "\033[0m");

function log_section($title) {
    echo "\n" . str_repeat('=', 80) . "\n";
    echo ANSI_CYAN . strtoupper($title) . ANSI_RESET . "\n";
    echo str_repeat('=', 80) . "\n";
}

function log_step($message, $status = 'info') {
    $prefix = match($status) {
        'success' => ANSI_GREEN . '[✓]' . ANSI_RESET,
        'error'   => ANSI_RED . '[✗]' . ANSI_RESET,
        'warning' => ANSI_YELLOW . '[!]' . ANSI_RESET,
        default   => ANSI_BLUE . '[•]' . ANSI_RESET,
    };
    echo "$prefix $message\n";
}

function check_php_syntax($dir) {
    log_section('Checking PHP Syntax');
    
    $files = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($dir)
    );
    
    $php_files = [];
    foreach ($files as $file) {
        if ($file->isFile() && $file->getExtension() === 'php') {
            $php_files[] = $file->getPathname();
        }
    }
    
    $errors = 0;
    $checked = 0;
    
    foreach ($php_files as $file) {
        $output = [];
        $return_var = 0;
        exec("php -l " . escapeshellarg($file) . " 2>&1", $output, $return_var);
        
        $checked++;
        if ($return_var !== 0) {
            log_step("Syntax error in " . basename($file), 'error');
            echo "    " . implode("\n    ", $output) . "\n";
            $errors++;
        }
    }
    
    if ($errors === 0) {
        log_step("All $checked PHP files have valid syntax", 'success');
    } else {
        log_step("$errors files have syntax errors", 'error');
    }
    
    return $errors === 0;
}

function check_class_definitions($dir) {
    log_section('Checking Class Definitions');
    
    $required_classes = [
        'includes/class-data-simulator.php' => 'RawWire_Data_Simulator',
        'includes/class-data-processor.php' => 'RawWire_Data_Processor',
        'includes/api/class-rest-api-controller.php' => 'RawWire_REST_API_Controller',
        'includes/class-logger.php' => 'RawWire_Logger',
        'includes/class-cache-manager.php' => 'RawWire_Cache_Manager',
        'includes/class-github-fetcher.php' => 'RawWire_GitHub_Fetcher',
    ];
    
    $all_found = true;
    foreach ($required_classes as $file => $class) {
        $filepath = $dir . '/' . $file;
        if (!file_exists($filepath)) {
            log_step("File not found: $file", 'error');
            $all_found = false;
            continue;
        }
        
        $content = file_get_contents($filepath);
        if (preg_match('/class\s+' . preg_quote($class) . '\b/', $content)) {
            log_step("$class defined in $file", 'success');
        } else {
            log_step("$class NOT FOUND in $file", 'error');
            $all_found = false;
        }
    }
    
    return $all_found;
}

function check_rest_endpoints($file) {
    log_section('Checking REST API Endpoints');
    
    if (!file_exists($file)) {
        log_step("REST controller file not found", 'error');
        return false;
    }
    
    $content = file_get_contents($file);
    
    $endpoints = [
        '/content' => 'GET',
        '/stats' => 'GET', 
        '/fetch-data' => 'POST',
        '/content/approve' => 'POST',
        '/content/snooze' => 'POST',
        '/clear-cache' => 'POST',
        '/admin/api-key/generate' => 'POST',
        '/admin/api-key/revoke' => 'POST',
    ];
    
    $found_count = 0;
    foreach ($endpoints as $endpoint => $method) {
        // Look for register_route calls
        if (preg_match('/register_route.*[\'"]' . preg_quote($endpoint) . '[\'"]/', $content)) {
            log_step("Endpoint $method $endpoint registered", 'success');
            $found_count++;
        } else {
            log_step("Endpoint $method $endpoint NOT FOUND", 'warning');
        }
    }
    
    log_step("Found $found_count/" . count($endpoints) . " endpoints", 
        $found_count === count($endpoints) ? 'success' : 'warning');
    
    return true;
}

function check_simulator_templates($file) {
    log_section('Checking Simulator Data Templates');
    
    if (!file_exists($file)) {
        log_step("Simulator file not found", 'error');
        return false;
    }
    
    $content = file_get_contents($file);
    
    $templates = [
        'get_federal_register_templates',
        'get_court_ruling_templates',
        'get_sec_filing_templates',
        'get_press_release_templates',
    ];
    
    $shock_levels = ['high', 'medium', 'low'];
    
    $all_found = true;
    foreach ($templates as $template) {
        if (preg_match('/function\s+' . preg_quote($template) . '\s*\(/', $content)) {
            log_step("Template method: $template", 'success');
            
            // Count templates for each shock level
            foreach ($shock_levels as $level) {
                $pattern = '/\$' . $level . '_shock\s*=\s*array\s*\(/';
                if (preg_match($pattern, $content, $matches, PREG_OFFSET_CAPTURE)) {
                    $start = $matches[0][1];
                    $end = strpos($content, ');', $start);
                    $section = substr($content, $start, $end - $start);
                    $count = substr_count($section, "'title'");
                    log_step("  $level shock: $count templates", 'info');
                }
            }
        } else {
            log_step("Template method NOT FOUND: $template", 'error');
            $all_found = false;
        }
    }
    
    // Check for generate_batch method
    if (preg_match('/function\s+generate_batch\s*\(/', $content)) {
        log_step("Main method: generate_batch()", 'success');
    } else {
        log_step("Main method generate_batch() NOT FOUND", 'error');
        $all_found = false;
    }
    
    // Check for populate_database method  
    if (preg_match('/function\s+populate_database\s*\(/', $content)) {
        log_step("Public method: populate_database()", 'success');
    } else {
        log_step("Public method populate_database() NOT FOUND", 'error');
        $all_found = false;
    }
    
    return $all_found;
}

function check_database_schema($file) {
    log_section('Checking Database Schema');
    
    if (!file_exists($file)) {
        log_step("Schema file not found", 'error');
        return false;
    }
    
    $content = file_get_contents($file);
    
    $required_fields = [
        'id',
        'title',
        'content',
        'source_url',
        'source_type',
        'document_number',
        'published_date',
        'agency',
        'relevance_score',
        'status',
        'created_at',
        'updated_at',
    ];
    
    $all_found = true;
    foreach ($required_fields as $field) {
        if (preg_match('/`' . preg_quote($field) . '`/', $content)) {
            log_step("Field: $field", 'success');
        } else {
            log_step("Field NOT FOUND: $field", 'error');
            $all_found = false;
        }
    }
    
    // Check for indexes
    $indexes = ['status', 'relevance_score', 'published_date'];
    foreach ($indexes as $index) {
        if (preg_match('/KEY.*' . preg_quote($index) . '/', $content)) {
            log_step("Index: $index", 'success');
        } else {
            log_step("Index missing: $index", 'warning');
        }
    }
    
    return $all_found;
}

function check_module_config($dir) {
    log_section('Checking Module Configuration');
    
    $module_file = $dir . '/templates/raw-wire-default.json';
    
    if (!file_exists($module_file)) {
        log_step("Module config file not found", 'error');
        return false;
    }
    
    $json = file_get_contents($module_file);
    $config = json_decode($json, true);
    
    if (json_last_error() !== JSON_ERROR_NONE) {
        log_step("Invalid JSON: " . json_last_error_msg(), 'error');
        return false;
    }
    
    log_step("Valid JSON configuration", 'success');
    
    // Check required sections
    $sections = ['metadata', 'keywords', 'financial_impact', 'recency'];
    foreach ($sections as $section) {
        if (isset($config[$section])) {
            log_step("Section: $section", 'success');
            
            // Show parameter count for this section
            if (is_array($config[$section])) {
                $param_count = count($config[$section]);
                log_step("  Parameters: $param_count", 'info');
            }
        } else {
            log_step("Section missing: $section", 'warning');
        }
    }
    
    return true;
}

function check_security_features($dir) {
    log_section('Checking Security Features');
    
    $security_files = [
        'includes/auth.php' => ['check_permission', 'verify_nonce'],
        'includes/rate-limit.php' => ['check_rate_limit', 'rate_limit'],
        'dashboard.js' => ['sanitize', 'escapeHtml'],
    ];
    
    $all_found = true;
    foreach ($security_files as $file => $functions) {
        $filepath = $dir . '/' . $file;
        if (!file_exists($filepath)) {
            log_step("Security file not found: $file", 'warning');
            continue;
        }
        
        $content = file_get_contents($filepath);
        log_step("File: $file", 'info');
        
        foreach ($functions as $func) {
            if (preg_match('/function\s+' . preg_quote($func) . '\b/', $content)) {
                log_step("  Function: $func", 'success');
            } else {
                log_step("  Function missing: $func", 'warning');
            }
        }
    }
    
    // Check for nonce usage
    $main_file = $dir . '/raw-wire-dashboard.php';
    if (file_exists($main_file)) {
        $content = file_get_contents($main_file);
        if (preg_match('/wp_verify_nonce|check_ajax_referer/', $content)) {
            log_step("Nonce verification present", 'success');
        } else {
            log_step("No nonce verification found", 'warning');
        }
    }
    
    return true;
}

function generate_summary($results) {
    log_section('Validation Summary');
    
    $total = count($results);
    $passed = array_sum($results);
    $failed = $total - $passed;
    
    echo "\nTest Results:\n";
    foreach ($results as $test => $result) {
        $status = $result ? ANSI_GREEN . 'PASS' : ANSI_RED . 'FAIL';
        echo "  $status" . ANSI_RESET . " - $test\n";
    }
    
    echo "\n" . str_repeat('=', 80) . "\n";
    $pass_rate = $total > 0 ? ($passed / $total * 100) : 0;
    $summary = sprintf("FINAL RESULT: %d/%d checks passed (%.1f%%)", $passed, $total, $pass_rate);
    
    if ($pass_rate === 100) {
        echo ANSI_GREEN . $summary . ANSI_RESET . "\n";
    } elseif ($pass_rate >= 80) {
        echo ANSI_YELLOW . $summary . ANSI_RESET . "\n";
    } else {
        echo ANSI_RED . $summary . ANSI_RESET . "\n";
    }
    echo str_repeat('=', 80) . "\n\n";
    
    return $pass_rate === 100;
}

// Main execution
echo "\n";
echo ANSI_CYAN . "╔════════════════════════════════════════════════════════════════════════════╗\n";
echo "║         RawWire Dashboard - Code Validation Script v1.0.13                ║\n";
echo "╚════════════════════════════════════════════════════════════════════════════╝" . ANSI_RESET . "\n";

$plugin_dir = __DIR__;

$results = [
    'PHP Syntax' => check_php_syntax($plugin_dir),
    'Class Definitions' => check_class_definitions($plugin_dir),
    'REST Endpoints' => check_rest_endpoints($plugin_dir . '/includes/api/class-rest-api-controller.php'),
    'Simulator Templates' => check_simulator_templates($plugin_dir . '/includes/class-data-simulator.php'),
    'Database Schema' => check_database_schema($plugin_dir . '/includes/schema.sql'),
    'Module Configuration' => check_module_config($plugin_dir),
    'Security Features' => check_security_features($plugin_dir),
];

$success = generate_summary($results);

echo ANSI_GREEN . "✓ Code validation complete!\n\n" . ANSI_RESET;
echo "Next steps:\n";
echo "  1. Install plugin on WordPress staging site\n";
echo "  2. Activate plugin to create database tables\n";
echo "  3. Run: php seed-test-data.php\n";
echo "  4. Verify dashboard displays seeded data\n";
echo "  5. Test all REST API endpoints\n\n";

exit($success ? 0 : 1);
