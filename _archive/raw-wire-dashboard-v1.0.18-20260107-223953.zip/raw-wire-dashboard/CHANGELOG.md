# Changelog

## [1.0.12] - 2025-01-XX

### Added - Production-Grade Foundation Layer

**Error Handling**
- `class-error-boundary.php`: Comprehensive exception handling system
  - `wrap_module_call()`: Protects module initialization and method calls
  - `wrap_ajax_call()`: Wraps AJAX handlers with try-catch and logging
  - `wrap_rest_call()`: Protects REST endpoints from exceptions
  - `wrap_db_call()`: Adds error handling to database operations
  - `with_timeout()`: Prevents infinite loops in long-running operations
  - All exceptions logged to activity logs with severity levels

**Input Validation**
- `class-validator.php`: Type-safe input validation system
  - `register_schema()`: Define validation schemas for endpoints
  - `validate()`: Schema-based validation with detailed error messages
  - Sanitizers: `sanitize_int/float/enum/bool/array/slug/email/url/json/date()`
  - Range checking, enum whitelisting, type coercion
  - Prevents SQL injection and invalid data from reaching business logic

**Initialization System**
- `class-init-controller.php`: Deterministic 6-phase boot sequence
  - Phase 1: Core utilities (Logger, Error Boundary, Validator)
  - Phase 1.5: Permissions system
  - Phase 2: Database migrations
  - Phase 3: Module system (Plugin Manager)
  - Phase 4: REST API and Admin UI registration
  - Phase 5: Legacy compatibility layer
  - Phase 6: Bootstrap UI components
  - Health check endpoint: `GET /wp-json/rawwire/v1/health`
  - Eliminates race conditions from fragmented initialization

**Permissions System**
- `class-permissions.php`: Role-based access control
  - Custom capabilities: `rawwire_view_dashboard`, `rawwire_manage_modules`, `rawwire_edit_config`, etc.
  - `check()`: Verify user has capability
  - `require_capability()`: Die with 403 if missing permission (for AJAX)
  - `rest_permission_check()`: Returns WP_Error for REST endpoints
  - `grant_capability()` / `revoke_capability()`: Dynamic permission assignment
  - Administrators granted all capabilities by default
  - Editors granted view-only capabilities

### Changed

**Core Architecture**
- Main plugin file (`raw-wire-dashboard.php`) refactored
  - Replaced 50 lines of fragmented initialization with single `RawWire_Init_Controller::init()` call
  - Single entry point on `plugins_loaded` hook
  - Version bumped to 1.0.12

**AJAX Handlers**
- All activity log AJAX handlers hardened with error boundaries:
  - `ajax_get_logs()`: Wrapped in `wrap_ajax_call()`, added enum/int validation
  - `ajax_clear_logs()`: Protected from exceptions, logs cleared atomically
  - `ajax_get_info()`: Safe info retrieval with error logging
  - Manual try-catch blocks removed (handled by error boundary)
  - Input validation centralized using `RawWire_Validator` methods

**Logger Enhancement**
- `class-logger.php`: Severity now stored in `details` JSON column
  - Enables UI filtering by severity (info, warning, error)
  - Query: `WHERE JSON_EXTRACT(details, '$.severity') = 'error'`

### Security

- All AJAX handlers require nonce verification (existing)
- All AJAX handlers require capability checks (new)
- Input validation prevents type coercion attacks
- Error messages sanitized before logging/display
- Health check endpoint exposes no sensitive data (only counts and status)

### Developer Experience

**New Helper Methods**
```php
// Error handling
RawWire_Error_Boundary::wrap_ajax_call(callable $callback, string $action_name);
RawWire_Error_Boundary::wrap_module_call(string $module_name, callable $callback);

// Input validation
RawWire_Validator::sanitize_enum($value, array $allowed_values, string $default);
RawWire_Validator::sanitize_int($value, int $min = PHP_INT_MIN, int $max = PHP_INT_MAX, int $default = 0);

// Permissions
RawWire_Permissions::require_capability('rawwire_view_logs');
RawWire_Permissions::rest_permission_check('rawwire_manage_modules');
```

**Health Check Endpoint**
```bash
curl https://yoursite.com/wp-json/rawwire/v1/health
```

Response:
```json
{
  "status": "healthy",
  "version": "1.0.12",
  "timestamp": 1704067200,
  "database": "connected",
  "tables": {
    "wp_rawwire_automation_log": "exists",
    "wp_rawwire_content": "exists"
  },
  "modules_loaded": 3
}
```

### Testing

- All error boundaries validated with forced exceptions
- Input validator tested with malformed inputs (SQL injection attempts, type mismatches)
- Init controller tested with missing dependencies
- Permissions system tested with Editor and Administrator roles
- Health endpoint tested on staging environment

### Migration Notes

**For Administrators:**
1. Deactivate plugin in WordPress admin
2. Replace plugin files via FTP/SFTP
3. Reactivate plugin (runs migrations automatically)
4. Verify health endpoint: `/wp-json/rawwire/v1/health`
5. Check activity logs for any initialization errors

**For Developers:**
- All existing AJAX handlers remain compatible (error boundaries are transparent wrappers)
- Modules using `interface-feature.php` require no changes
- New modules should use `RawWire_Error_Boundary::wrap_module_call()` in init methods
- REST endpoints should use `RawWire_Permissions::rest_permission_check()` in `permission_callback`

### Upgrade Path

From v1.0.11 to v1.0.12:
- No database schema changes
- No breaking API changes
- Safe to deploy to production with zero downtime
- Custom modules remain compatible (new safety layer is additive)

---

## [1.0.11] - 2025-01-XX

### Fixed
- Logger severity storage: Severity now stored in `details` JSON for UI filtering
- Dashboard Core initialization order
- Activity logs tab not populating on staging site

### Added
- Dashboard Core initialization on admin and frontend contexts
- Enhanced error logging for initialization failures

---

## [1.0.10] - Previous Release

(Earlier versions not documented)
