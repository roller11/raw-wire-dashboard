<?php

/**
 * Plugin Name: RawWire Dashboard
 * Plugin URI: https://github.com/raw-wire-dao-llc/raw-wire-core
 * Description: Production-ready control panel for Raw-Wire automation with GitHub API integration, modular search logic, and comprehensive data management
 * Version: 1.0.18
 * Author: Raw-Wire DAO LLC
 * Author URI: https://github.com/raw-wire-dao-llc
 * Text Domain: raw-wire-dashboard
 * Domain Path: /languages
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * RawWire Dashboard Main Plugin Class
 *
 * @since 1.0.18
 */
class RawWire_Dashboard {

    /**
     * Single instance of the plugin
     *
     * @var RawWire_Dashboard
     */
    private static $instance = null;

    /**
     * Plugin version
     */
    const VERSION = '1.0.18';

    /**
     * Get single instance of the plugin
     *
     * @return RawWire_Dashboard
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Constructor
     */
    private function __construct() {
        $this->init_hooks();
        $this->includes();
    }

    /**
     * Initialize WordPress hooks
     */
    private function init_hooks() {
        add_action('init', array($this, 'init'));
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_assets'));
        add_action('rest_api_init', array($this, 'register_rest_routes'));
        register_activation_hook(__FILE__, array($this, 'activate'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate'));
    }

    /**
     * Include required files
     */
    private function includes() {
        // Core classes
        require_once plugin_dir_path(__FILE__) . 'includes/class-logger.php';
        require_once plugin_dir_path(__FILE__) . 'includes/class-rest-api.php';
        require_once plugin_dir_path(__FILE__) . 'includes/class-admin.php';

        // Module core system
        require_once plugin_dir_path(__FILE__) . 'cores/module-core/module-core.php';

        // Initialize module core to discover modules
        RawWire_Module_Core::init();

        // Instantiate admin class to register AJAX handlers
        new RawWire_Admin();

        // Admin classes
        if (is_admin()) {
            require_once plugin_dir_path(__FILE__) . 'admin/class-dashboard.php';
        }
    }

    /**
     * Plugin initialization
     */
    public function init() {
        // Load text domain
        load_plugin_textdomain('raw-wire-dashboard', false, dirname(plugin_basename(__FILE__)) . '/languages');

        // Initialize components
        $this->init_database();
    }

    /**
     * Initialize database
     */
    private function init_database() {
        // Database initialization will be handled here
    }

    /**
     * Add admin menu
     */
    public function add_admin_menu() {
        add_menu_page(
            __('Raw-Wire Dashboard', 'raw-wire-dashboard'),
            __('Raw-Wire', 'raw-wire-dashboard'),
            'manage_options',
            'raw-wire-dashboard',
            array($this, 'admin_page'),
            'dashicons-chart-line',
            26
        );
        // Add submenus: Settings and Approvals
        add_submenu_page(
            'raw-wire-dashboard',
            __('Settings', 'raw-wire-dashboard'),
            __('Settings', 'raw-wire-dashboard'),
            'manage_options',
            'raw-wire-settings',
            array($this, 'admin_settings_page')
        );

        add_submenu_page(
            'raw-wire-dashboard',
            __('Approvals', 'raw-wire-dashboard'),
            __('Approvals', 'raw-wire-dashboard'),
            'manage_options',
            'raw-wire-approvals',
            array($this, 'admin_approvals_page')
        );
    }

    /**
     * Admin page callback
     */
    public function admin_page() {
        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this page.'));
        }

        $admin = new RawWire_Admin_Dashboard();
        $admin->render();
    }

    /**
     * Settings page callback
     */
    public function admin_settings_page() {
        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this page.'));
        }

        require_once plugin_dir_path(__FILE__) . 'admin/class-settings.php';
        $page = new RawWire_Settings_Page();
        $page->render();
    }

    /**
     * Approvals page callback
     */
    public function admin_approvals_page() {
        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this page.'));
        }

        require_once plugin_dir_path(__FILE__) . 'admin/class-approvals.php';
        $page = new RawWire_Approvals_Page();
        $page->render();
    }

    /**
     * Enqueue admin assets
     */
    public function enqueue_admin_assets($hook) {
        if ('toplevel_page_raw-wire-dashboard' !== $hook && 
            'raw-wire_page_raw-wire-settings' !== $hook && 
            'raw-wire_page_raw-wire-approvals' !== $hook) {
            return;
        }

        wp_enqueue_style(
            'rawwire-admin',
            plugin_dir_url(__FILE__) . 'assets/css/admin.css',
            array(),
            self::VERSION
        );

        wp_enqueue_script(
            'rawwire-admin',
            plugin_dir_url(__FILE__) . 'assets/js/admin.js',
            array('jquery'),
            self::VERSION,
            true
        );

        wp_localize_script('rawwire-admin', 'rawwire_ajax', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('rawwire_ajax_nonce'),
        ));
    }

    /**
     * Register REST API routes
     */
    public function register_rest_routes() {
        $api = new RawWire_REST_API();
        $api->register_routes();
    }

    /**
     * Plugin activation
     */
    public function activate() {
        // Create database tables
        $this->create_tables();

        // Set default options
        add_option('rawwire_version', self::VERSION);
        add_option('rawwire_last_sync', __('Never', 'raw-wire-dashboard'));

        // Flush rewrite rules
        flush_rewrite_rules();
    }

    /**
     * Plugin deactivation
     */
    public function deactivate() {
        // Clear scheduled events
        wp_clear_scheduled_hook('rawwire_sync_data');

        // Flush rewrite rules
        flush_rewrite_rules();
    }

    /**
     * Create database tables
     */
    private function create_tables() {
        global $wpdb;

        $charset_collate = $wpdb->get_charset_collate();

        $table_name = $wpdb->prefix . 'rawwire_content';

        $sql = "CREATE TABLE $table_name (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            title text NOT NULL,
            content longtext NOT NULL,
            status varchar(20) NOT NULL DEFAULT 'pending',
            source varchar(50) NOT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            INDEX status_index (status),
            INDEX source_index (source)
        ) $charset_collate;";

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }
}

/**
 * Initialize the plugin
 */
function rawwire_dashboard() {
    return RawWire_Dashboard::get_instance();
}

// Start the plugin
rawwire_dashboard();