<div class="wrap rawwire-dashboard" data-rawwire-template="<?php echo esc_attr($template_config['name'] ?? 'raw-wire-default'); ?>">
    <h1 style="position: absolute; left: -9999px;">Raw-Wire Dashboard</h1>
    
    <header class="rawwire-hero">
        <div>
            <p class="eyebrow"><?php echo esc_html( $module['hero']['site_name'] ?? 'Raw-Wire · Findings Control' ); ?></p>
            <h1 style="position: static;"><?php echo esc_html( $module['hero']['tagline'] ?? 'Signal-driven curation' ); ?></h1>
            <p class="lede"><?php echo esc_html( $module['hero']['description'] ?? 'Top findings per source, ranked, scored, and ready for human approval.' ); ?></p>
            <div class="hero-meta">
                <span class="pill">Template: <?php echo esc_html($template_config['name'] ?? 'raw-wire-default'); ?></span>
                <span class="pill subtle">Last Sync: <?php echo esc_html($stats['last_sync']); ?></span>
            </div>
        </div>
        <div class="hero-actions">
            <div class="button-group">
                <button id="fetch-data-btn" class="button button-primary" data-requires-cap="manage_options">
                    <span class="dashicons dashicons-update"></span> Sync Sources
                </button>
                <button id="clear-cache-btn" class="button ghost" data-requires-cap="manage_options">
                    <span class="dashicons dashicons-trash"></span> Clear Cache
                </button>
            </div>
            <div id="control-status" class="status-message" aria-live="polite"></div>
        </div>
    </header>

    <section class="stat-deck">
        <?php
        $stats_cards = $module['stats']['cards'] ?? array();
        if (empty($stats_cards)) {
            // Fallback to hard-coded cards if module config is missing
            $stats_cards = array(
                array('label' => 'Total Findings', 'field' => 'total', 'subtitle' => 'Across all sources'),
                array('label' => 'Pending Review', 'field' => 'pending', 'subtitle' => 'Awaiting human judgment'),
                array('label' => 'Approved', 'field' => 'approved', 'subtitle' => 'Ready for distribution'),
                array('label' => 'Fresh (24h)', 'field' => 'fresh_24h', 'subtitle' => 'Recent, higher-signal items'),
                array('label' => 'Avg Score', 'field' => 'avg_score', 'subtitle' => 'Weighted relevance', 'highlight' => true),
            );
        }
        
        foreach ($stats_cards as $card) {
            $label = esc_html($card['label'] ?? '');
            $field = $card['field'] ?? '';
            $value = esc_html($ui_metrics[$field] ?? '0');
            $subtitle = esc_html($card['subtitle'] ?? '');
            $highlight_class = !empty($card['highlight']) ? ' highlight' : '';
            ?>
            <div class="stat-card<?php echo $highlight_class; ?>">
                <p><?php echo $label; ?></p>
                <h2><?php echo $value; ?></h2>
                <small><?php echo $subtitle; ?></small>
            </div>
            <?php
        }
        ?>
    </section>

    <section class="control-bar">
        <div class="filter-group">
            <label>
                Source
                <select id="filter-source">
                    <option value="">All sources</option>
                    <?php foreach (($template_config['filters']['sources'] ?? []) as $source): ?>
                        <option value="<?php echo esc_attr($source); ?>"><?php echo esc_html(ucfirst($source)); ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
            <label>
                Category
                <select id="filter-category">
                    <option value="">All categories</option>
                    <?php foreach (($template_config['filters']['categories'] ?? []) as $category): ?>
                        <option value="<?php echo esc_attr($category); ?>"><?php echo esc_html(ucfirst($category)); ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
            <label>
                Status
                <select id="filter-status">
                    <option value="">Any status</option>
                    <?php foreach (($template_config['filters']['statuses'] ?? []) as $status): ?>
                        <option value="<?php echo esc_attr($status); ?>"><?php echo esc_html(ucfirst($status)); ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
            <label class="slider-label">
                Min Score <span id="score-value">0</span>
                <input type="range" id="filter-score" min="0" max="100" step="5" value="0" />
            </label>
        </div>
        <div class="quick-filters">
            <button class="chip" data-filter="fresh">Fresh 24h</button>
            <button class="chip" data-filter="pending">Pending</button>
            <button class="chip" data-filter="approved">Approved</button>
            <button class="chip" data-filter="highscore">Score > 80</button>
        </div>
    </section>

    <section class="board">
        <div class="board-main">
            <div class="board-header">
                <div>
                    <p class="eyebrow">Top Findings</p>
                    <h3>Ranked list · multi-source</h3>
                </div>
                <span class="pill subtle">Showing up to 20 recent items</span>
            </div>

            <?php if (!empty($findings)): ?>
                <div class="finding-list" id="finding-list">
                    <?php foreach ($findings as $finding): ?>
                        <article class="finding-card"
                            data-id="<?php echo esc_attr($finding['id']); ?>"
                            data-source="<?php echo esc_attr($finding['source']); ?>"
                            data-category="<?php echo esc_attr($finding['category']); ?>"
                            data-status="<?php echo esc_attr($finding['status']); ?>"
                            data-score="<?php echo esc_attr($finding['score']); ?>"
                            data-rank="<?php echo esc_attr($finding['rank']); ?>"
                            data-freshness="<?php echo esc_attr($finding['freshness'] ?? 0); ?>"
                            data-link="<?php echo esc_url($finding['link']); ?>"
                            data-title="<?php echo esc_attr($finding['title']); ?>"
                            data-summary="<?php echo esc_attr($finding['summary'] ?: ''); ?>"
                            data-confidence="<?php echo esc_attr(number_format($finding['confidence'] * 100, 0)); ?>"
                            data-tags="<?php echo esc_attr(implode(',', $finding['tags'] ?? [])); ?>">
                            <div class="finding-rank">#<?php echo esc_html($finding['rank']); ?></div>
                            <div class="finding-body">
                                <div class="finding-top">
                                    <div>
                                        <h4 class="finding-title"><?php echo esc_html($finding['title']); ?></h4>
                                        <p class="finding-meta">
                                            <span class="badge tone-info"><?php echo esc_html(ucfirst($finding['source'])); ?></span>
                                            <span class="badge tone-muted"><?php echo esc_html($finding['category']); ?></span>
                                            <span class="badge tone-outline">Score: <?php echo esc_html($finding['score']); ?></span>
                                            <span class="badge tone-muted"><?php echo esc_html($finding['freshness_label']); ?></span>
                                        </p>
                                    </div>
                                    <div class="finding-actions">
                                        <button class="button button-small ghost approve-btn" data-id="<?php echo esc_attr($finding['id']); ?>">Approve</button>
                                        <button class="button button-small ghost snooze-btn" data-id="<?php echo esc_attr($finding['id']); ?>">Snooze</button>
                                    </div>
                                </div>
                                <p class="finding-summary"><?php echo esc_html($finding['summary'] ?: 'No summary available yet.'); ?></p>
                                <div class="finding-tags">
                                    <?php foreach (($finding['tags'] ?? []) as $tag): ?>
                                        <span class="tag"><?php echo esc_html($tag); ?></span>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                            <div class="finding-meta-col">
                                <div class="mini-stat">
                                    <span class="label">Confidence</span>
                                    <strong><?php echo esc_html(number_format($finding['confidence'] * 100, 0)); ?>%</strong>
                                </div>
                                <div class="mini-stat">
                                    <span class="label">Status</span>
                                    <span class="pill tone-<?php echo esc_attr($finding['status']); ?>"><?php echo esc_html(ucfirst($finding['status'])); ?></span>
                                </div>
                                <?php if (!empty($finding['link'])): ?>
                                    <a class="text-link" href="<?php echo esc_url($finding['link']); ?>" target="_blank" rel="noopener">Open source</a>
                                <?php endif; ?>
                            </div>
                        </article>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="empty-state" role="status">
                    <span class="dashicons dashicons-admin-post" style="font-size: 48px; opacity: 0.3; margin-bottom: 16px;"></span>
                    <h3 style="margin: 0 0 8px 0; font-size: 18px;">No findings yet</h3>
                    <p style="margin: 0 0 16px 0; color: #666;">Click "Sync Sources" above to fetch and analyze data</p>
                    <button class="button button-primary" onclick="document.getElementById('fetch-data-btn').click();">Get Started</button>
                </div>
            <?php endif; ?>
        </div>

        <aside class="insights-panel">
            <div class="panel-block">
                <p class="eyebrow">Signals</p>
                <h4>What we’re tracking</h4>
                <ul class="stacked">
                    <li>Novelty vs. historical baseline</li>
                    <li>Regulatory and compliance triggers</li>
                    <li>Market and sentiment drift</li>
                    <li>Technical risk/bug density</li>
                </ul>
            </div>
            <div class="panel-block">
                <p class="eyebrow">Template-ready</p>
                <p>UI reads from template configs so you can swap industries or data vocab without reworking PHP/JS.</p>
                <div class="pill-row">
                    <span class="pill subtle">GitHub</span>
                    <span class="pill subtle">Filings</span>
                    <span class="pill subtle">News</span>
                </div>
            </div>
            <div class="panel-block">
                <p class="eyebrow">System</p>
                <p><strong>DB Version:</strong> <?php echo esc_html(get_option('rawwire_db_version', 'Unknown')); ?></p>
                <p><strong>Last Sync:</strong> <?php echo esc_html($stats['last_sync']); ?></p>
            </div>
        </aside>
    </section>

    <section class="dashboard-section rawwire-activity-logs">
        <div class="section-header">
            <div>
                <p class="eyebrow">Activity Logs</p>
                <h3>System monitoring & error tracking</h3>
            </div>
            <div class="logs-controls">
                <div class="logs-stats">
                    <span class="stat-item">
                        <span class="dashicons dashicons-info"></span>
                        <span id="info-count">0</span> Info
                    </span>
                    <span class="stat-item">
                        <span class="dashicons dashicons-admin-tools"></span>
                        <span id="debug-count">0</span> Debug
                    </span>
                    <span class="stat-item">
                        <span class="dashicons dashicons-warning"></span>
                        <span id="error-count">0</span> Errors
                    </span>
                </div>
                <div class="button-group">
                    <button id="refresh-logs" class="button">
                        <span class="dashicons dashicons-update"></span> Refresh
                    </button>
                    <button id="clear-logs" class="button" data-requires-cap="manage_options">
                        <span class="dashicons dashicons-trash"></span> Clear All
                    </button>
                    <button id="export-logs" class="button">
                        <span class="dashicons dashicons-download"></span> Export
                    </button>
                </div>
            </div>
        </div>

        <!-- Sync Status Section -->
        <div class="sync-status-panel">
            <div class="sync-info-grid">
                <div class="sync-info-item">
                    <span class="dashicons dashicons-clock"></span>
                    <div>
                        <strong>Last Sync:</strong>
                        <span id="last-sync-time"><?php echo esc_html($stats['last_sync']); ?></span>
                    </div>
                </div>
                <div class="sync-info-item">
                    <span class="dashicons dashicons-database"></span>
                    <div>
                        <strong>Total Items:</strong>
                        <span id="total-items"><?php echo esc_html($stats['total_issues']); ?></span>
                    </div>
                </div>
                <div class="sync-info-item">
                    <span class="dashicons dashicons-yes-alt"></span>
                    <div>
                        <strong>Approved:</strong>
                        <span id="approved-count"><?php echo esc_html($stats['approved_issues']); ?></span>
                    </div>
                </div>
                <div class="sync-info-item">
                    <span class="dashicons dashicons-hourglass"></span>
                    <div>
                        <strong>Pending:</strong>
                        <span id="pending-count"><?php echo esc_html($stats['pending_issues']); ?></span>
                    </div>
                </div>
            </div>
            
            <?php if (!empty($findings) && count($findings) > 0): ?>
            <div class="recent-entries-list">
                <h4 class="recent-entries-title">
                    <span class="dashicons dashicons-editor-ul"></span>
                    Recent Entries (Last <?php echo min(5, count($findings)); ?>)
                </h4>
                <ul class="recent-items">
                    <?php foreach (array_slice($findings, 0, 5) as $finding): ?>
                    <li class="recent-item">
                        <span class="recent-item-badge tone-<?php echo esc_attr($finding['status']); ?>">
                            <?php echo esc_html(ucfirst($finding['status'])); ?>
                        </span>
                        <span class="recent-item-title" title="<?php echo esc_attr($finding['title']); ?>">
                            <?php echo esc_html(wp_trim_words($finding['title'], 10)); ?>
                        </span>
                        <span class="recent-item-meta">
                            Score: <?php echo esc_html($finding['score']); ?> | 
                            <?php echo esc_html($finding['freshness_label']); ?>
                        </span>
                    </li>
                    <?php endforeach; ?>
                </ul>
            </div>
            <?php else: ?>
            <div class="no-recent-entries">
                <span class="dashicons dashicons-info"></span>
                <p>No recent entries. Click "Sync Sources" to fetch data.</p>
            </div>
            <?php endif; ?>
        </div>

        <!-- Tab Navigation -->
        <div class="activity-logs-tabs">
            <button class="tab-button active" data-tab="info">
                <span class="dashicons dashicons-info"></span> Info
            </button>
            <button class="tab-button" data-tab="debug">
                <span class="dashicons dashicons-admin-tools"></span> Debug
            </button>
            <button class="tab-button" data-tab="error">
                <span class="dashicons dashicons-warning"></span> Errors
            </button>
        </div>

        <!-- Tab Content -->
        <div id="info-tab" class="tab-pane active">
            <div class="logs-container" data-type="info">
                <div class="logs-loading">
                    <span class="spinner is-active"></span> Loading logs...
                </div>
            </div>
        </div>

        <div id="debug-tab" class="tab-pane">
            <div class="logs-container" data-type="debug">
                <div class="logs-loading">
                    <span class="spinner is-active"></span> Loading debug logs...
                </div>
            </div>
        </div>

        <div id="error-tab" class="tab-pane">
            <div class="logs-container" data-type="error">
                <div class="logs-loading">
                    <span class="spinner is-active"></span> Loading logs...
                </div>
            </div>
        </div>
    </section>

    <aside class="drawer" id="finding-drawer" role="dialog" aria-modal="true" aria-hidden="true" aria-labelledby="drawer-title">
        <div class="drawer-header">
            <div>
                <p class="eyebrow">Finding details</p>
                <h3 id="drawer-title">Select a finding</h3>
            </div>
            <button class="button ghost" id="drawer-close" aria-label="Close drawer">Close</button>
        </div>
        <div class="drawer-body">
            <p id="drawer-summary" class="drawer-summary">Click any finding card to see full context.</p>
            <div class="drawer-meta" id="drawer-meta" role="list"></div>
            <div class="drawer-tags" id="drawer-tags"></div>
            <div class="drawer-actions">
                <button class="button button-primary" id="drawer-approve" data-requires-cap="manage_options">Approve</button>
                <button class="button ghost" id="drawer-snooze" data-requires-cap="manage_options">Snooze</button>
                <a class="text-link" id="drawer-link" href="#" target="_blank" rel="noopener">Open source</a>
            </div>
        </div>
    </aside>
</div>