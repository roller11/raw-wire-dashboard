<?php
/**
 * RawWire Module Simulator Bootstrap
 *
 * Registers the module simulator with the RawWire core system.
 * This allows the dashboard to function without external modules.
 */

if (!defined('ABSPATH')) {
    exit;
}

// Include the simulator class
require_once plugin_dir_path(dirname(dirname(__FILE__))) . 'includes/class-module-simulator.php';

// Register the simulator module
RawWire_Module_Core::register_module('module-simulator', new RawWire_Module_Simulator());

// Log successful registration
if (class_exists('RawWire_Logger')) {
    RawWire_Logger::log(
        'Module Simulator registered successfully',
        'info',
        array('module' => 'module-simulator', 'action' => 'module_init')
    );
}