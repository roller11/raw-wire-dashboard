jQuery(document).ready(function($) {
    const cards = $('.finding-card');
    const drawer = $('#finding-drawer');
    const status = $('#control-status');
    let currentDrawerId = null;
    let lastFocusedElement = null;

    // OPTIMIZATION 1: Debounce helper for search/filter
    function debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }

    // OPTIMIZATION 2: Lazy load images/content
    const lazyLoadObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const lazyElement = entry.target;
                if (lazyElement.dataset.src) {
                    lazyElement.src = lazyElement.dataset.src;
                    lazyElement.classList.remove('lazy');
                    lazyLoadObserver.unobserve(lazyElement);
                }
            }
        });
    });

    document.querySelectorAll('.lazy').forEach(el => lazyLoadObserver.observe(el));

    // OPTIMIZATION 3: Component caching
    const componentCache = new Map();
    function getCachedComponent(key, generator) {
        if (componentCache.has(key)) {
            return componentCache.get(key);
        }
        const component = generator();
        componentCache.set(key, component);
        return component;
    }

    // OPTIMIZATION 4: Progressive enhancement - core works without JS
    // (Already implemented via server-side rendering)

    // OPTIMIZATION 5: Optimistic UI updates
    function optimisticUpdate(element, action, rollback) {
        const originalState = element.clone();
        action();
        return {
            success: () => {},
            failure: () => {
                element.replaceWith(originalState);
                if (rollback) rollback();
            }
        };
    }

    // === CAPABILITY-AWARE UI ===
    // Hide/disable buttons that require capabilities the user doesn't have
    const initCapabilityAwareUI = () => {
        if (!RawWireCfg || !RawWireCfg.userCaps) return;
        
        $('[data-requires-cap]').each(function() {
            const btn = $(this);
            const requiredCap = btn.data('requires-cap');
            
            if (!RawWireCfg.userCaps[requiredCap]) {
                // User lacks capability - disable button and add tooltip
                btn.prop('disabled', true)
                   .attr('title', 'Requires administrator privileges')
                   .css('opacity', '0.5')
                   .css('cursor', 'not-allowed');
            }
        });
    };

    // === DRAWER ACCESSIBILITY ===
    // Trap focus inside drawer when open
    const focusableSelectors = 'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])';
    
    const trapFocus = (e) => {
        if (!drawer.hasClass('open')) return;
        
        const focusableElements = drawer.find(focusableSelectors).filter(':visible');
        const firstFocusable = focusableElements.first();
        const lastFocusable = focusableElements.last();
        
        if (e.key === 'Tab') {
            if (e.shiftKey && document.activeElement === firstFocusable[0]) {
                e.preventDefault();
                lastFocusable.focus();
            } else if (!e.shiftKey && document.activeElement === lastFocusable[0]) {
                e.preventDefault();
                firstFocusable.focus();
            }
        }
    };
    
    // Close drawer on ESC key
    const handleEscape = (e) => {
        if (e.key === 'Escape' && drawer.hasClass('open')) {
            closeDrawer();
        }
    };
    
    $(document).on('keydown', trapFocus);
    $(document).on('keydown', handleEscape);

    // === ERROR/LOADING STATES ===
    const showError = (message, retry = false) => {
        const retryHtml = retry ? 
            '<button class="button" onclick="location.reload();" style="margin-left: 8px;">Retry</button>' : '';
        status.html(
            '<div class="notice notice-error" role="alert">' +
            '<p><span class="dashicons dashicons-warning" style="color: #dc3232;"></span> ' + 
            message + retryHtml + '</p></div>'
        );
    };

    const showLoading = (message) => {
        status.html(
            '<div class="notice notice-info" role="status">' +
            '<p><span class="spinner is-active" style="float: none; margin: 0 8px 0 0;"></span>' + 
            message + '</p></div>'
        );
    };

    // Sync
    $('#fetch-data-btn').on('click', function(e) {
        e.preventDefault();
        const btn = $(this);
        btn.prop('disabled', true).html('<span class="dashicons dashicons-update spin"></span> Syncing...');
        showLoading('Fetching sources...');
            const payload = {};
            // Default to simulator mode if no obvious external configuration exists.
            // This keeps the dashboard usable out-of-the-box with test data.
            const hasApiKey = !!(RawWireCfg && (RawWireCfg.hasApiKey || RawWireCfg.apiKey));
            if (!hasApiKey) {
              payload.simulate = true;
              payload.count = 20;
              payload.shock_level = 'mixed';
            }

            $.ajax({
                url: RawWireCfg.rest + '/fetch-data',
                method: 'POST',
                beforeSend: (xhr) => xhr.setRequestHeader('X-WP-Nonce', RawWireCfg.nonce),
                data: JSON.stringify(payload),
                contentType: 'application/json',
                success: (response) => {
                    status.html('<div class="notice notice-success" role="status"><p>✓ Synced ' + (response.count || 0) + ' items</p></div>');
                    setTimeout(() => location.reload(), 1200);
                },
                error: (xhr) => {
                    const msg = (xhr.responseJSON && xhr.responseJSON.message) || 'Failed to sync sources';
                    showError(msg, true);
                    btn.prop('disabled', false).html('<span class="dashicons dashicons-update"></span> Sync Sources');
                }
            });
    });

    // Clear cache
    $('#clear-cache-btn').on('click', function(e) {
        e.preventDefault();
        const btn = $(this);
        btn.prop('disabled', true);
        showLoading('Clearing cache...');
        $.ajax({
            url: RawWireCfg.rest + '/clear-cache',
            method: 'POST',
            beforeSend: (xhr) => xhr.setRequestHeader('X-WP-Nonce', RawWireCfg.nonce),
            success: () => {
                status.html('<div class="notice notice-success" role="status"><p>✓ Cache cleared</p></div>');
                btn.prop('disabled', false);
            },
            error: (xhr) => {
                const msg = (xhr.responseJSON && xhr.responseJSON.message) || 'Failed to clear cache';
                showError(msg, false);
                btn.prop('disabled', false);
            }
        });
    });

    // Filters
    const applyFilters = () => {
        const source = $('#filter-source').val();
        const category = $('#filter-category').val();
        const statusVal = $('#filter-status').val();
        const minScore = parseFloat($('#filter-score').val() || '0');
        const quick = $('.chip.active').data('filter');

        cards.each(function() {
            const card = $(this);
            const cSource = card.data('source');
            const cCategory = card.data('category');
            const cStatus = card.data('status');
            const cScore = parseFloat(card.data('score')) || 0;
            const freshness = parseFloat(card.data('freshness')) || 0;

            let visible = true;
            if (source && cSource !== source) visible = false;
            if (category && cCategory !== category) visible = false;
            if (statusVal && cStatus !== statusVal) visible = false;
            if (cScore < minScore) visible = false;

            if (quick === 'fresh' && freshness > 86400) visible = false;
            if (quick === 'pending' && cStatus !== 'pending') visible = false;
            if (quick === 'approved' && cStatus !== 'approved') visible = false;
            if (quick === 'highscore' && cScore < 80) visible = false;

            card.toggle(visible);
        });
    };

    $('#filter-source, #filter-category, #filter-status').on('change', applyFilters);
    $('#filter-score').on('input change', function() {
        $('#score-value').text($(this).val());
        applyFilters();
    });
    $('.chip').on('click', function() {
        const chip = $(this);
        if (chip.hasClass('active')) {
            chip.removeClass('active');
        } else {
            $('.chip').removeClass('active');
            chip.addClass('active');
        }
        applyFilters();
    });

    // Drawer
    const openDrawer = (card) => {
        // Store last focused element for return focus
        lastFocusedElement = document.activeElement;
        
        currentDrawerId = parseInt(card.data('id'), 10) || null;
        $('#drawer-title').text(card.data('title') || 'Finding');
        $('#drawer-summary').text(card.data('summary') || 'No summary available yet.');
        const meta = [
            'Source: ' + (card.data('source') || 'N/A'),
            'Category: ' + (card.data('category') || 'N/A'),
            'Score: ' + (card.data('score') || 0),
            'Confidence: ' + (card.data('confidence') || 0) + '%',
            'Status: ' + (card.data('status') || 'pending'),
            'Freshness: ' + card.data('freshness') + 's'
        ];
        $('#drawer-meta').html(meta.map((m) => '<div role="listitem">' + m + '</div>').join(''));

        const tags = (card.data('tags') || '').toString().split(',').filter(Boolean);
        $('#drawer-tags').html(tags.map((t) => '<span class="tag">' + t + '</span>').join(''));

        const link = card.data('link');
        if (link) {
            $('#drawer-link').attr('href', link).show();
        } else {
            $('#drawer-link').hide();
        }

        drawer.addClass('open').attr('aria-hidden', 'false');
        
        // Focus first focusable element (close button)
        setTimeout(() => {
            drawer.find(focusableSelectors).filter(':visible').first().focus();
        }, 100);
    };
    
    const closeDrawer = () => {
        drawer.removeClass('open').attr('aria-hidden', 'true');
        
        // Return focus to trigger element
        if (lastFocusedElement) {
            lastFocusedElement.focus();
            lastFocusedElement = null;
        }
    };

    cards.on('click', function(e) {
        if ($(e.target).closest('button').length) return; // allow button handlers to run
        openDrawer($(this));
    });
    $('#drawer-close').on('click', closeDrawer);

    // Approve/Snooze placeholders (UI feedback; hook actual endpoints later)
    const toast = (msg, tone) => {
        const toneClass = tone === 'success' ? 'notice-success' : 
                         tone === 'error' ? 'notice-error' : 'notice-info';
        const icon = tone === 'success' ? 'yes-alt' : 
                    tone === 'error' ? 'warning' : 'info';
        status.html(
            '<div class="notice ' + toneClass + '" role="status">' +
            '<p><span class="dashicons dashicons-' + icon + '"></span> ' + msg + '</p></div>'
        );
        setTimeout(() => status.empty(), 2500);
    };

    $(document).on('click', '.approve-btn', function(e) {
        e.stopPropagation();
        const btn = $(this);
        const id = parseInt(btn.attr('data-id'), 10);
        if (!id || !RawWireCfg.rest) return;

        btn.prop('disabled', true);
        $.ajax({
            url: RawWireCfg.rest + '/content/approve',
            method: 'POST',
            beforeSend: (xhr) => xhr.setRequestHeader('X-WP-Nonce', RawWireCfg.nonce),
            data: JSON.stringify({ content_ids: [id] }),
            contentType: 'application/json',
            success: () => {
                toast('Approved', 'success');
                setTimeout(() => location.reload(), 500);
            },
            error: (xhr) => {
                const msg = (xhr.responseJSON && xhr.responseJSON.message) || 'Approve failed';
                toast(msg, 'error');
                btn.prop('disabled', false);
            }
        });
    });

    $(document).on('click', '.snooze-btn', function(e) {
        e.stopPropagation();
        const btn = $(this);
        const id = parseInt(btn.attr('data-id'), 10);
        if (!id || !RawWireCfg.rest) return;

        btn.prop('disabled', true);
        $.ajax({
            url: RawWireCfg.rest + '/content/snooze',
            method: 'POST',
            beforeSend: (xhr) => xhr.setRequestHeader('X-WP-Nonce', RawWireCfg.nonce),
            data: JSON.stringify({ content_ids: [id], minutes: 60 }),
            contentType: 'application/json',
            success: () => {
                toast('Snoozed for 60 minutes', 'info');
                setTimeout(() => location.reload(), 500);
            },
            error: (xhr) => {
                const msg = (xhr.responseJSON && xhr.responseJSON.message) || 'Snooze failed';
                toast(msg, 'error');
                btn.prop('disabled', false);
            }
        });
    });

    $('#drawer-approve').on('click', function(e) {
        e.preventDefault();
        if (!currentDrawerId || !RawWireCfg.rest) return;
        const btn = $(this);
        btn.prop('disabled', true);
        $.ajax({
            url: RawWireCfg.rest + '/content/approve',
            method: 'POST',
            beforeSend: (xhr) => xhr.setRequestHeader('X-WP-Nonce', RawWireCfg.nonce),
            data: JSON.stringify({ content_ids: [currentDrawerId] }),
            contentType: 'application/json',
            success: () => {
                toast('Approved', 'success');
                setTimeout(() => location.reload(), 500);
            },
            error: (xhr) => {
                const msg = (xhr.responseJSON && xhr.responseJSON.message) || 'Approve failed';
                toast(msg, 'error');
                btn.prop('disabled', false);
            }
        });
    });

    $('#drawer-snooze').on('click', function(e) {
        e.preventDefault();
        if (!currentDrawerId || !RawWireCfg.rest) return;
        const btn = $(this);
        btn.prop('disabled', true);
        $.ajax({
            url: RawWireCfg.rest + '/content/snooze',
            method: 'POST',
            beforeSend: (xhr) => xhr.setRequestHeader('X-WP-Nonce', RawWireCfg.nonce),
            data: JSON.stringify({ content_ids: [currentDrawerId], minutes: 60 }),
            contentType: 'application/json',
            success: () => {
                toast('Snoozed for 60 minutes', 'info');
                setTimeout(() => location.reload(), 500);
            },
            error: (xhr) => {
                const msg = (xhr.responseJSON && xhr.responseJSON.message) || 'Snooze failed';
                toast(msg, 'error');
                btn.prop('disabled', false);
            }
        });
    });

    // === ACTIVITY LOGS - THREE TAB SYSTEM ===
    const activityLogsModule = {
        currentTab: 'info',
        cache: {
            info: null,
            debug: null,
            errors: null
        },
        isLoading: false,

        init() {
            this.bindTabSwitching();
            this.bindExportButton();
            this.loadTab('info'); // Load info tab by default
        },

        bindTabSwitching() {
            $('.activity-logs-tab').on('click', (e) => {
                e.preventDefault();
                const tab = $(e.currentTarget);
                const tabType = tab.data('tab');
                
                if (tabType === this.currentTab) return; // Already on this tab
                
                // Update tab UI
                $('.activity-logs-tab').removeClass('active');
                tab.addClass('active');
                
                // Show corresponding pane
                $('.logs-pane').removeClass('active');
                $('#' + tabType + '-tab').addClass('active');
                
                // Load logs for this tab
                this.loadTab(tabType);
            });
        },

        bindExportButton() {
            $('#export-logs-btn').on('click', () => {
                this.exportLogs();
            });
        },

        loadTab(tabType) {
            if (this.isLoading) return;
            
            this.currentTab = tabType;
            const container = $('#' + tabType + '-tab .logs-container');
            
            // Check cache first
            if (this.cache[tabType]) {
                this.renderLogs(container, this.cache[tabType]);
                return;
            }
            
            // Show loading state
            this.isLoading = true;
            container.html('<div class="logs-loading"><span class="spinner is-active"></span> Loading ' + tabType + ' logs...</div>');
            
            // Fetch logs via AJAX
            $.ajax({
                url: RawWireCfg.ajaxurl,
                method: 'POST',
                data: {
                    action: 'rawwire_get_logs',
                    type: tabType,
                    nonce: RawWireCfg.nonce
                },
                success: (response) => {
                    this.isLoading = false;
                    
                    if (response.success && response.data && response.data.logs) {
                        this.cache[tabType] = response.data.logs;
                        this.renderLogs(container, response.data.logs);
                    } else {
                        container.html('<div class="logs-error"><span class="dashicons dashicons-warning"></span> Failed to load logs</div>');
                    }
                },
                error: (xhr) => {
                    this.isLoading = false;
                    const msg = (xhr.responseJSON && xhr.responseJSON.message) || 'Network error';
                    container.html('<div class="logs-error"><span class="dashicons dashicons-warning"></span> ' + msg + '</div>');
                }
            });
        },

        renderLogs(container, logs) {
            if (!logs || logs.length === 0) {
                container.html('<div class="logs-empty"><span class="dashicons dashicons-info"></span> No ' + this.currentTab + ' logs found</div>');
                return;
            }
            
            let html = '<table class="logs-table widefat">';
            html += '<thead><tr>';
            html += '<th style="width: 150px;">Time</th>';
            html += '<th style="width: 100px;">Type</th>';
            html += '<th style="width: 80px;">Severity</th>';
            html += '<th>Message</th>';
            html += '<th style="width: 100px;">Actions</th>';
            html += '</tr></thead>';
            html += '<tbody>';
            
            logs.forEach((log) => {
                const severityClass = 'severity-' + (log.severity || 'info');
                const details = log.details ? JSON.stringify(log.details, null, 2) : '{}';
                const detailsEscaped = details.replace(/"/g, '&quot;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
                
                html += '<tr class="log-row ' + severityClass + '">';
                html += '<td><span class="log-time">' + this.formatTime(log.created_at) + '</span></td>';
                html += '<td><span class="log-type">' + (log.event_type || 'N/A') + '</span></td>';
                html += '<td><span class="log-severity ' + severityClass + '">' + (log.severity || 'info') + '</span></td>';
                html += '<td><span class="log-message">' + this.escapeHtml(log.message || 'No message') + '</span></td>';
                html += '<td><button class="button button-small view-details-btn" data-details="' + detailsEscaped + '" title="View Details">Details</button></td>';
                html += '</tr>';
            });
            
            html += '</tbody></table>';
            container.html(html);
            
            // Bind details button
            container.find('.view-details-btn').on('click', (e) => {
                const btn = $(e.currentTarget);
                const details = btn.data('details');
                this.showDetailsModal(details);
            });
        },

        formatTime(timestamp) {
            if (!timestamp) return 'N/A';
            const date = new Date(timestamp);
            const now = new Date();
            const diff = Math.floor((now - date) / 1000); // seconds
            
            if (diff < 60) return diff + 's ago';
            if (diff < 3600) return Math.floor(diff / 60) + 'm ago';
            if (diff < 86400) return Math.floor(diff / 3600) + 'h ago';
            if (diff < 604800) return Math.floor(diff / 86400) + 'd ago';
            
            return date.toLocaleString();
        },

        escapeHtml(text) {
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        },

        showDetailsModal(details) {
            // Create modal overlay
            const modal = $('<div class="logs-modal-overlay"></div>');
            const modalContent = $('<div class="logs-modal-content"></div>');
            
            modalContent.html(
                '<div class="logs-modal-header">' +
                '<h3>Log Details</h3>' +
                '<button class="logs-modal-close" title="Close">&times;</button>' +
                '</div>' +
                '<div class="logs-modal-body">' +
                '<pre>' + details + '</pre>' +
                '</div>' +
                '<div class="logs-modal-footer">' +
                '<button class="button logs-modal-close">Close</button>' +
                '</div>'
            );
            
            modal.append(modalContent);
            $('body').append(modal);
            
            // Bind close handlers
            modal.find('.logs-modal-close').on('click', () => {
                modal.fadeOut(200, () => modal.remove());
            });
            
            modal.on('click', (e) => {
                if ($(e.target).hasClass('logs-modal-overlay')) {
                    modal.fadeOut(200, () => modal.remove());
                }
            });
            
            // ESC key to close
            $(document).on('keydown.logsModal', (e) => {
                if (e.key === 'Escape') {
                    modal.fadeOut(200, () => modal.remove());
                    $(document).off('keydown.logsModal');
                }
            });
            
            modal.fadeIn(200);
        },

        exportLogs() {
            const logs = this.cache[this.currentTab];
            if (!logs || logs.length === 0) {
                toast('No logs to export', 'info');
                return;
            }
            
            // Convert to CSV
            let csv = 'Time,Type,Severity,Message,Details\n';
            logs.forEach((log) => {
                const time = log.created_at || '';
                const type = log.event_type || '';
                const severity = log.severity || 'info';
                const message = (log.message || '').replace(/"/g, '""');
                const details = log.details ? JSON.stringify(log.details).replace(/"/g, '""') : '';
                
                csv += '"' + time + '","' + type + '","' + severity + '","' + message + '","' + details + '"\n';
            });
            
            // Download file
            const blob = new Blob([csv], { type: 'text/csv' });
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = 'rawwire-logs-' + this.currentTab + '-' + Date.now() + '.csv';
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            window.URL.revokeObjectURL(url);
            
            toast('Logs exported successfully', 'success');
        }
    };

    // === SYNC STATUS - REAL-TIME UPDATES ===
    const updateSyncStatus = () => {
        // Update last sync time from server
        $.ajax({
            url: RawWireCfg.rest + '/stats',
            method: 'GET',
            beforeSend: (xhr) => xhr.setRequestHeader('X-WP-Nonce', RawWireCfg.nonce),
            success: (response) => {
                if (response && response.last_sync) {
                    $('#last-sync-value').text(formatTimeAgo(response.last_sync));
                }
                if (response && response.total_items !== undefined) {
                    $('#total-items-value').text(response.total_items);
                }
                if (response && response.approved_count !== undefined) {
                    $('#approved-count-value').text(response.approved_count);
                }
                if (response && response.pending_count !== undefined) {
                    $('#pending-count-value').text(response.pending_count);
                }
            },
            error: () => {
                // Silently fail - don't disrupt user experience
            }
        });
    };

    const formatTimeAgo = (timestamp) => {
        if (!timestamp) return 'Never';
        const date = new Date(timestamp * 1000); // Assuming Unix timestamp
        const now = new Date();
        const diff = Math.floor((now - date) / 1000);
        
        if (diff < 60) return 'Just now';
        if (diff < 3600) return Math.floor(diff / 60) + ' minutes ago';
        if (diff < 86400) return Math.floor(diff / 3600) + ' hours ago';
        if (diff < 604800) return Math.floor(diff / 86400) + ' days ago';
        
        return date.toLocaleDateString();
    };

    // Initialize
    initCapabilityAwareUI();
    $('#score-value').text($('#filter-score').val());
    applyFilters();
    
    // Initialize activity logs module
    if ($('.activity-logs-tabs').length > 0) {
        activityLogsModule.init();
    }
    
    // Initialize sync status updates
    if ($('#sync-status-panel').length > 0) {
        updateSyncStatus();
        // Update every 30 seconds
        setInterval(updateSyncStatus, 30000);
    }
});
