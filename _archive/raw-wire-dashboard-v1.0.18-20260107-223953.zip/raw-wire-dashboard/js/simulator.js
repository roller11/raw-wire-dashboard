/**
 * RawWire Module Simulator JavaScript
 */

(function($) {
    'use strict';

    /**
     * RawWire Module Simulator
     */
    var RawWireSimulator = {

        /**
         * Initialize the simulator
         */
        init: function() {
            this.bindEvents();
            this.loadInitialData();
        },

        /**
         * Bind event handlers
         */
        bindEvents: function() {
            var self = this;

            // Approve button clicks
            $(document).on('click', '.approve-btn', function(e) {
                e.preventDefault();
                var itemId = $(this).data('id');
                self.approveItem(itemId, $(this));
            });

            // Reject button clicks
            $(document).on('click', '.reject-btn', function(e) {
                e.preventDefault();
                var itemId = $(this).data('id');
                self.rejectItem(itemId, $(this));
            });

            // Settings form submission
            $(document).on('submit', '.rawwire-settings-form', function(e) {
                e.preventDefault();
                self.saveSettings($(this));
            });

            // Auto-refresh data
            setInterval(function() {
                self.refreshData();
            }, 30000); // Refresh every 30 seconds
        },

        /**
         * Load initial data
         */
        loadInitialData: function() {
            this.showLoading('.rawwire-data-table-panel .panel-content');
            this.fetchData('research_findings');
        },

        /**
         * Fetch data from the simulator
         */
        fetchData: function(type, callback) {
            var self = this;

            $.ajax({
                url: rawwireSimulator.ajax_url,
                type: 'POST',
                data: {
                    action: 'rawwire_simulator_fetch',
                    nonce: rawwireSimulator.nonce,
                    type: type
                },
                success: function(response) {
                    if (response.success) {
                        self.hideLoading();
                        if (callback) {
                            callback(response.data);
                        } else {
                            self.updateDataTable(response.data);
                        }
                    } else {
                        self.showError(response.data || rawwireSimulator.strings.error);
                    }
                },
                error: function() {
                    self.hideLoading();
                    self.showError(rawwireSimulator.strings.error);
                }
            });
        },

        /**
         * Update data table with new data
         */
        updateDataTable: function(data) {
            var $tbody = $('.rawwire-data-table tbody');
            if (!$tbody.length) return;

            $tbody.empty();

            $.each(data, function(index, item) {
                var $row = $('<tr>');
                $row.append($('<td>').text(item.rank || ''));
                $row.append($('<td>').text(item.title || ''));
                $row.append($('<td>').text(item.source || ''));
                $row.append($('<td>').text(item.category || ''));
                $row.append($('<td>').text(item.score || ''));
                $row.append($('<td>').text(item.freshness || ''));
                $row.append($('<td>').text(item.status || ''));

                var $actions = $('<td>');
                $actions.append($('<button>')
                    .addClass('button button-small approve-btn')
                    .data('id', item.id)
                    .text('Approve'));
                $actions.append($('<button>')
                    .addClass('button button-small reject-btn')
                    .data('id', item.id)
                    .text('Reject'));

                $row.append($actions);
                $tbody.append($row);
            });
        },

        /**
         * Approve an item
         */
        approveItem: function(itemId, $button) {
            var self = this;

            $button.prop('disabled', true).text('Approving...');

            $.ajax({
                url: rawwireSimulator.ajax_url,
                type: 'POST',
                data: {
                    action: 'rawwire_simulator_approve',
                    nonce: rawwireSimulator.nonce,
                    item_id: itemId
                },
                success: function(response) {
                    if (response.success) {
                        $button.closest('tr').find('td:nth-child(7)').text('approved');
                        $button.remove();
                        self.showSuccess('Item approved successfully');
                    } else {
                        self.showError(response.data || 'Failed to approve item');
                        $button.prop('disabled', false).text('Approve');
                    }
                },
                error: function() {
                    self.showError('Failed to approve item');
                    $button.prop('disabled', false).text('Approve');
                }
            });
        },

        /**
         * Reject an item
         */
        rejectItem: function(itemId, $button) {
            var self = this;

            $button.prop('disabled', true).text('Rejecting...');

            $.ajax({
                url: rawwireSimulator.ajax_url,
                type: 'POST',
                data: {
                    action: 'rawwire_simulator_reject',
                    nonce: rawwireSimulator.nonce,
                    item_id: itemId
                },
                success: function(response) {
                    if (response.success) {
                        $button.closest('tr').find('td:nth-child(7)').text('rejected');
                        $button.remove();
                        self.showSuccess('Item rejected successfully');
                    } else {
                        self.showError(response.data || 'Failed to reject item');
                        $button.prop('disabled', false).text('Reject');
                    }
                },
                error: function() {
                    self.showError('Failed to reject item');
                    $button.prop('disabled', false).text('Reject');
                }
            });
        },

        /**
         * Save settings
         */
        saveSettings: function($form) {
            var self = this;
            var formData = $form.serializeArray();
            var settings = {};

            $.each(formData, function(index, field) {
                settings[field.name] = field.value;
            });

            $.ajax({
                url: rawwireSimulator.ajax_url,
                type: 'POST',
                data: {
                    action: 'rawwire_simulator_save_settings',
                    nonce: rawwireSimulator.nonce,
                    settings: JSON.stringify(settings)
                },
                success: function(response) {
                    if (response.success) {
                        self.showSuccess('Settings saved successfully');
                    } else {
                        self.showError(response.data || 'Failed to save settings');
                    }
                },
                error: function() {
                    self.showError('Failed to save settings');
                }
            });
        },

        /**
         * Refresh data periodically
         */
        refreshData: function() {
            // Only refresh if we're on a page with data tables
            if ($('.rawwire-data-table').length) {
                this.fetchData('research_findings');
            }
        },

        /**
         * Show loading state
         */
        showLoading: function(selector) {
            $(selector).html('<div class="rawwire-loading">' + rawwireSimulator.strings.loading + '</div>');
        },

        /**
         * Hide loading state
         */
        hideLoading: function() {
            $('.rawwire-loading').remove();
        },

        /**
         * Show error message
         */
        showError: function(message) {
            this.showMessage(message, 'error');
        },

        /**
         * Show success message
         */
        showSuccess: function(message) {
            this.showMessage(message, 'success');
        },

        /**
         * Show message to user
         */
        showMessage: function(message, type) {
            // Remove existing messages
            $('.rawwire-message').remove();

            var $message = $('<div>')
                .addClass('rawwire-message rawwire-' + type)
                .text(message);

            // Insert at the top of the first panel
            $('.rawwire-panel').first().prepend($message);

            // Auto-hide after 5 seconds
            setTimeout(function() {
                $message.fadeOut(function() {
                    $(this).remove();
                });
            }, 5000);
        }
    };

    // Initialize when document is ready
    $(document).ready(function() {
        RawWireSimulator.init();
    });

    // Expose to global scope for debugging
    window.RawWireSimulator = RawWireSimulator;

})(jQuery);