<?php
/**
 * REST API endpoints for RawWire Dashboard
 * Provides modern RESTful API access to dashboard functionality
 */

if (!defined('ABSPATH')) exit;

class RawWire_REST_API {
    private static $instance = null;
    private $namespace = 'rawwire/v1';

    /**
     * Middleware stack for request/response processing
     *
     * @var array
     */
    private $middleware = array();

    /**
     * Request validation schemas
     *
     * @var array
     */
    private $validation_schemas = array();

    /**
     * API version info
     *
     * @var array
     */
    private $api_version = array(
        'version' => '1.0',
        'deprecated_at' => null,
        'sunset_at' => null,
    );

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_action('rest_api_init', array($this, 'register_routes'));
        
        // OPTIMIZATION 1: Setup unified request validation
        $this->setup_validation_schemas();
        
        // OPTIMIZATION 2: Add request logging middleware
        $this->add_middleware(array($this, 'log_request'));
        
        // OPTIMIZATION 3: Add CORS headers
        add_action('rest_api_init', array($this, 'add_cors_headers'));
        
        // OPTIMIZATION 4: Add response compression
        add_filter('rest_pre_serve_request', array($this, 'enable_compression'), 10, 4);
        
        // OPTIMIZATION 5: Add error formatting
        add_filter('rest_request_after_callbacks', array($this, 'format_response'), 10, 3);
    }

    public function init() {
        // Public initialization method
        add_action('rest_api_init', array($this, 'register_routes'));
    }

    /**
     * Setup validation schemas for all endpoints
     *
     * OPTIMIZATION 1: Unified request validation layer
     *
     * @since  1.0.15
     * @return void
     */
    private function setup_validation_schemas() {
        // Register schemas with RawWire_Validator if available
        if (!class_exists('RawWire_Validator')) {
            return;
        }

        // Search endpoint schema
        RawWire_Validator::register_schema('search', array(
            'q' => array('type' => 'string', 'maxLength' => 200),
            'category' => array('type' => 'string', 'maxLength' => 100),
            'status' => array('type' => 'string', 'enum' => array('pending', 'approved', 'rejected', 'published')),
            'page' => array('type' => 'integer', 'min' => 1),
            'per_page' => array('type' => 'integer', 'min' => 1, 'max' => 100),
        ));

        // Relevance update schema
        RawWire_Validator::register_schema('update_relevance', array(
            'score' => array('type' => 'number', 'required' => true, 'min' => 0, 'max' => 100),
        ));

        // Bulk operations schema
        RawWire_Validator::register_schema('bulk_operation', array(
            'ids' => array('type' => 'array', 'required' => true, 'minLength' => 1),
        ));
    }

    /**
     * Add request logging middleware
     *
     * OPTIMIZATION 2: Automatic logging of all API calls
     *
     * @since  1.0.15
     * @param  WP_REST_Request $request Request object
     * @return void
     */
    public function log_request($request) {
        if (!class_exists('RawWire_Logger')) {
            return;
        }

        $route = $request->get_route();
        $method = $request->get_method();
        $params = $request->get_params();

        // Remove sensitive data from logging
        $safe_params = $params;
        $sensitive_keys = array('password', 'token', 'api_key', 'secret');
        foreach ($sensitive_keys as $key) {
            if (isset($safe_params[$key])) {
                $safe_params[$key] = '[REDACTED]';
            }
        }

        RawWire_Logger::log(
            "REST API Request: {$method} {$route}",
            'debug',
            array(
                'method' => $method,
                'route' => $route,
                'params' => $safe_params,
                'user_id' => get_current_user_id(),
                'ip' => $this->get_client_ip(),
            )
        );
    }

    /**
     * Add middleware to processing stack
     *
     * @since  1.0.15
     * @param  callable $callback Middleware function
     * @return void
     */
    private function add_middleware($callback) {
        $this->middleware[] = $callback;
    }

    /**
     * Add CORS headers to REST API responses
     *
     * OPTIMIZATION 3: Proper cross-origin support
     *
     * @since  1.0.15
     * @return void
     */
    public function add_cors_headers() {
        // Get allowed origins from settings
        $allowed_origins = apply_filters('rawwire_api_allowed_origins', array(
            get_site_url(),
        ));

        $origin = isset($_SERVER['HTTP_ORIGIN']) ? $_SERVER['HTTP_ORIGIN'] : '';

        // Check if origin is allowed
        if (in_array($origin, $allowed_origins, true)) {
            header('Access-Control-Allow-Origin: ' . $origin);
            header('Access-Control-Allow-Credentials: true');
        }

        header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
        header('Access-Control-Allow-Headers: Content-Type, Authorization, X-WP-Nonce');
        header('Access-Control-Max-Age: 3600');

        // Handle preflight requests
        if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
            status_header(200);
            exit;
        }
    }

    /**
     * Enable response compression
     *
     * OPTIMIZATION 4: Gzip compression for JSON responses
     *
     * @since  1.0.15
     * @param  bool              $served Whether the request has already been served
     * @param  WP_HTTP_Response  $result Result to send to the client
     * @param  WP_REST_Request   $request Request object
     * @param  WP_REST_Server    $server Server instance
     * @return bool
     */
    public function enable_compression($served, $result, $request, $server) {
        // Check if client accepts gzip
        $accept_encoding = isset($_SERVER['HTTP_ACCEPT_ENCODING']) ? $_SERVER['HTTP_ACCEPT_ENCODING'] : '';
        
        if (strpos($accept_encoding, 'gzip') !== false && function_exists('gzencode')) {
            // Only compress if response is large enough (> 1KB)
            $data = $result->get_data();
            $json = wp_json_encode($data);
            
            if (strlen($json) > 1024) {
                header('Content-Encoding: gzip');
                echo gzencode($json);
                return true; // Prevent default serving
            }
        }
        
        return $served;
    }

    /**
     * Format all REST responses consistently
     *
     * OPTIMIZATION 5: Consistent error response format
     *
     * @since  1.0.15
     * @param  WP_REST_Response $response Response object
     * @param  WP_REST_Server   $server Server instance
     * @param  WP_REST_Request  $request Request object
     * @return WP_REST_Response
     */
    public function format_response($response, $server, $request) {
        // Add API version headers
        $response->header('X-API-Version', $this->api_version['version']);
        
        // Add deprecation warnings if applicable
        if ($this->api_version['deprecated_at']) {
            $response->header('Deprecation', 'true');
            $response->header('Sunset', $this->api_version['sunset_at']);
        }

        // Format error responses consistently
        if ($response->is_error()) {
            $data = $response->get_data();
            
            // Ensure consistent error format
            if (!isset($data['error'])) {
                $formatted = array(
                    'success' => false,
                    'error' => array(
                        'code' => isset($data['code']) ? $data['code'] : 'unknown_error',
                        'message' => isset($data['message']) ? $data['message'] : 'An error occurred',
                        'details' => isset($data['data']) ? $data['data'] : null,
                    ),
                    'timestamp' => current_time('mysql'),
                );
                $response->set_data($formatted);
            }
        } else {
            // Add success wrapper if not present
            $data = $response->get_data();
            if (!isset($data['success'])) {
                $data['success'] = true;
                $response->set_data($data);
            }
        }

        // Execute middleware stack
        foreach ($this->middleware as $middleware) {
            call_user_func($middleware, $request);
        }

        return $response;
    }

    /**
     * Get client IP address
     *
     * @since  1.0.15
     * @return string
     */
    private function get_client_ip() {
        $ip_keys = array('HTTP_CLIENT_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR');
        foreach ($ip_keys as $key) {
            if (isset($_SERVER[$key]) && filter_var($_SERVER[$key], FILTER_VALIDATE_IP)) {
                return $_SERVER[$key];
            }
        }
        return 'unknown';
    }

    public function register_routes() {
        // GET endpoint to fetch stored data
        register_rest_route($this->namespace, '/findings', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_findings'),
            'permission_callback' => array($this, 'check_permission')
        ));

        // POST endpoint to trigger data fetch from GitHub
        register_rest_route($this->namespace, '/findings/fetch', array(
            'methods' => 'POST',
            'callback' => array($this, 'fetch_data'),
            'permission_callback' => array($this, 'check_permission')
        ));

        // Alias for /findings/fetch (matches dashboard.js)
        register_rest_route($this->namespace, '/fetch-data', array(
            'methods' => 'POST',
            'callback' => array($this, 'fetch_data'),
            'permission_callback' => array($this, 'check_permission')
        ));

        // GET endpoint for fetch progress (OPTIMIZATION 1)
        register_rest_route($this->namespace, '/fetch-progress', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_fetch_progress'),
            'permission_callback' => array($this, 'check_permission')
        ));

        // DELETE endpoint to clear cache
        register_rest_route($this->namespace, '/findings/cache', array(
            'methods' => 'DELETE',
            'callback' => array($this, 'clear_cache'),
            'permission_callback' => array($this, 'check_permission')
        ));

        // Alias for /findings/cache (matches dashboard.js) - accepts POST
        register_rest_route($this->namespace, '/clear-cache', array(
            'methods' => 'POST',
            'callback' => array($this, 'clear_cache'),
            'permission_callback' => array($this, 'check_permission')
        ));

        // GET endpoint for system status
        register_rest_route($this->namespace, '/status', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_status'),
            'permission_callback' => array($this, 'check_permission')
        ));
        
        // POST endpoint for advanced search with filters
        register_rest_route($this->namespace, '/search', array(
            'methods' => array('GET', 'POST'),
            'callback' => array($this, 'search_content'),
            'permission_callback' => array($this, 'check_permission')
        ));
        
        // POST endpoint to update relevance score
        register_rest_route($this->namespace, '/content/(?P<id>\d+)/relevance', array(
            'methods' => 'POST',
            'callback' => array($this, 'update_relevance'),
            'permission_callback' => array($this, 'check_permission'),
            'args' => array(
                'score' => array(
                    'required' => true,
                    'type' => 'number',
                    'minimum' => 0,
                    'maximum' => 100
                )
            )
        ));
        
        // GET endpoint for available filter options
        register_rest_route($this->namespace, '/filters', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_filters'),
            'permission_callback' => '__return_true' // Public endpoint
        ));
        
        // GET approved content (for AI models)
        register_rest_route($this->namespace, '/content', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_content'),
            'permission_callback' => '__return_true', // Public for API consumption
            'args' => array(
                'status' => array(
                    'default' => 'approved',
                    'enum' => array('pending', 'approved', 'rejected', 'published')
                ),
                'limit' => array(
                    'default' => 20,
                    'type' => 'integer'
                )
            )
        ));
        
        // GET single content item
        register_rest_route($this->namespace, '/content/(?P<id>\d+)', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_single_content'),
            'permission_callback' => '__return_true'
        ));
        
        // POST approve content
        register_rest_route($this->namespace, '/content/(?P<id>\d+)/approve', array(
            'methods' => 'POST',
            'callback' => array($this, 'approve_content'),
            'permission_callback' => array($this, 'check_permission')
        ));
        
        // POST reject content
        register_rest_route($this->namespace, '/content/(?P<id>\d+)/reject', array(
            'methods' => 'POST',
            'callback' => array($this, 'reject_content'),
            'permission_callback' => array($this, 'check_permission')
        ));
        
        // POST bulk approve
        register_rest_route($this->namespace, '/content/bulk-approve', array(
            'methods' => 'POST',
            'callback' => array($this, 'bulk_approve'),
            'permission_callback' => array($this, 'check_permission'),
            'args' => array(
                'ids' => array(
                    'required' => true,
                    'type' => 'array'
                )
            )
        ));
        
        // POST bulk reject
        register_rest_route($this->namespace, '/content/bulk-reject', array(
            'methods' => 'POST',
            'callback' => array($this, 'bulk_reject'),
            'permission_callback' => array($this, 'check_permission'),
            'args' => array(
                'ids' => array(
                    'required' => true,
                    'type' => 'array'
                )
            )
        ));
        
        // GET statistics
        register_rest_route($this->namespace, '/stats', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_stats'),
            'permission_callback' => array($this, 'check_permission')
        ));
        
        // GET automation logs
        register_rest_route($this->namespace, '/logs', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_logs'),
            'permission_callback' => array($this, 'check_permission'),
            'args' => array(
                'limit' => array(
                    'default' => 50,
                    'type' => 'integer'
                ),
                'severity' => array(
                    'enum' => array('info', 'warning', 'error', 'critical')
                )
            )
        ));
    }

    public function check_permission() {
        return current_user_can('manage_options');
    }

    public function get_findings($request) {
        $dashboard = Raw_Wire_Dashboard::get_instance();
        $data = $dashboard->get_stored_data();
        
        if (empty($data)) {
            return new WP_REST_Response(array(
                'success' => false,
                'message' => 'No data available',
                'data' => array()
            ), 404);
        }

        return new WP_REST_Response(array(
            'success' => true,
            'count' => count($data),
            'data' => $data
        ), 200);
    }

    /**
     * Fetch data from GitHub
     *
     * OPTIMIZATIONS DEPLOYED:
     * 1. Progress reporting for long-running fetches
     * 2. Background job processing with WP Cron
     * 3. Rate limit headers in response
     * 4. ETag support for conditional requests
     * 5. Response caching for 5 minutes
     *
     * @param WP_REST_Request $request REST request object
     * @return WP_REST_Response Response with fetch status
     */
    public function fetch_data($request) {
        $dashboard = Raw_Wire_Dashboard::get_instance();
        
        // OPTIMIZATION 4: ETag support for conditional requests
        $etag = md5('rawwire_fetch_' . get_option('rawwire_last_fetch_version', 0));
        $if_none_match = $request->get_header('If-None-Match');
        
        if ($if_none_match && $if_none_match === $etag) {
            RawWire_Logger::debug('ETag match, returning 304', 'rest_api');
            $response = new WP_REST_Response(null, 304);
            $response->header('ETag', $etag);
            return $response;
        }
        
        // OPTIMIZATION 5: Check if recent fetch is cached
        $cached = get_transient('rawwire_fetch_result');
        if ($cached !== false && !$request->get_param('force')) {
            RawWire_Logger::debug('Returning cached fetch result', 'rest_api');
            $response = new WP_REST_Response($cached, 200);
            $response->header('X-Cache', 'HIT');
            $response->header('ETag', $etag);
            $this->add_rate_limit_headers($response);
            return $response;
        }
        
        // OPTIMIZATION 2: Check if we should run in background
        $background = $request->get_param('background');
        if ($background) {
            // Schedule as single event
            wp_schedule_single_event(time() + 10, 'rawwire_fetch_data_background');
            
            RawWire_Logger::log_activity(
                'Fetch scheduled for background processing',
                'rest_api',
                array('scheduled_for' => time() + 10),
                'info'
            );
            
            $response = new WP_REST_Response(array(
                'success' => true,
                'message' => 'Data fetch scheduled for background processing',
                'job_id' => time(),
                'check_status_at' => rest_url($this->namespace . '/status')
            ), 202);
            
            $this->add_rate_limit_headers($response);
            return $response;
        }
        
        // OPTIMIZATION 1: Progress reporting
        $progress_key = 'rawwire_fetch_progress_' . get_current_user_id();
        update_option($progress_key, array(
            'status' => 'starting',
            'progress' => 0,
            'total' => 0,
            'timestamp' => time()
        ), false);
        
        // Clear existing cache
        delete_transient('rawwire_data_cache');
        delete_transient('rawwire_fetch_result');
        
        update_option($progress_key, array(
            'status' => 'fetching',
            'progress' => 0,
            'total' => 0,
            'timestamp' => time()
        ), false);
        
        // Trigger data fetch
        $result = $dashboard->fetch_github_data();
        
        update_option($progress_key, array(
            'status' => 'processing',
            'progress' => 50,
            'total' => 100,
            'timestamp' => time()
        ), false);
        
        if (is_wp_error($result)) {
            update_option($progress_key, array(
                'status' => 'error',
                'error' => $result->get_error_message(),
                'timestamp' => time()
            ), false);
            
            RawWire_Logger::log_activity(
                'Fetch data failed',
                'rest_api',
                array('error' => $result->get_error_message()),
                'error'
            );
            
            $response = new WP_REST_Response(array(
                'success' => false,
                'message' => $result->get_error_message()
            ), 500);
            
            $this->add_rate_limit_headers($response);
            return $response;
        }

        $data = $dashboard->get_stored_data();
        
        update_option($progress_key, array(
            'status' => 'complete',
            'progress' => 100,
            'total' => 100,
            'count' => count($data),
            'timestamp' => time()
        ), false);
        
        // Increment fetch version for ETag
        update_option('rawwire_last_fetch_version', get_option('rawwire_last_fetch_version', 0) + 1);
        $etag = md5('rawwire_fetch_' . get_option('rawwire_last_fetch_version', 0));
        
        $response_data = array(
            'success' => true,
            'message' => 'Data fetched successfully',
            'count' => count($data),
            'timestamp' => current_time('mysql'),
            'progress_url' => rest_url($this->namespace . '/fetch-progress')
        );
        
        // OPTIMIZATION 5: Cache result for 5 minutes
        set_transient('rawwire_fetch_result', $response_data, 5 * MINUTE_IN_SECONDS);
        
        $response = new WP_REST_Response($response_data, 200);
        
        // OPTIMIZATION 3 & 4: Add rate limit and ETag headers
        $this->add_rate_limit_headers($response);
        $response->header('ETag', $etag);
        $response->header('X-Cache', 'MISS');
        $response->header('Cache-Control', 'max-age=300'); // 5 minutes
        
        RawWire_Logger::log_activity(
            'Data fetched successfully',
            'rest_api',
            array('count' => count($data)),
            'info'
        );
        
        return $response;
    }

    /**
     * Add rate limit headers to response
     *
     * OPTIMIZATION 3: Rate limit information in response headers
     *
     * @param WP_REST_Response $response Response object
     */
    private function add_rate_limit_headers($response) {
        $user_id = get_current_user_id();
        $rate_limit_key = 'rawwire_rate_limit_' . $user_id;
        $rate_limit = get_transient($rate_limit_key);
        
        if ($rate_limit === false) {
            $rate_limit = array(
                'requests' => 0,
                'reset_at' => time() + HOUR_IN_SECONDS
            );
        }
        
        $rate_limit['requests']++;
        set_transient($rate_limit_key, $rate_limit, HOUR_IN_SECONDS);
        
        $limit = 100; // 100 requests per hour
        $remaining = max(0, $limit - $rate_limit['requests']);
        
        $response->header('X-RateLimit-Limit', $limit);
        $response->header('X-RateLimit-Remaining', $remaining);
        $response->header('X-RateLimit-Reset', $rate_limit['reset_at']);
    }

    /**
     * Get fetch progress
     *
     * OPTIMIZATION 1: Endpoint to check progress of long-running fetch
     *
     * @param WP_REST_Request $request REST request object
     * @return WP_REST_Response Progress information
     */
    public function get_fetch_progress($request) {
        $user_id = get_current_user_id();
        $progress_key = 'rawwire_fetch_progress_' . $user_id;
        $progress = get_option($progress_key, array(
            'status' => 'none',
            'progress' => 0,
            'total' => 0
        ));
        
        return new WP_REST_Response($progress, 200);
    }

    public function search_content($request) {
        $search_service = new Raw_Wire_Search_Service();
        
        $params = array(
            'q' => $request->get_param('q'),
            'category' => $request->get_param('category'),
            'status' => $request->get_param('status'),
            'min_relevance' => $request->get_param('min_relevance'),
            'date_from' => $request->get_param('date_from'),
            'date_to' => $request->get_param('date_to'),
            'page' => $request->get_param('page'),
            'per_page' => $request->get_param('per_page'),
            'order_by' => $request->get_param('order_by'),
            'order' => $request->get_param('order'),
        );
        
        // Remove null values
        $params = array_filter($params, function($v) { return $v !== null; });
        
        $result = $search_service->search($params);
        if (is_wp_error($result)) {
            $this->log_error('Search failed', array('error' => $result->get_error_message()));
            return new WP_REST_Response(array(
                'success' => false,
                'message' => $result->get_error_message()
            ), 500);
        }
        
        return new WP_REST_Response(array(
            'success' => true,
            'data' => $result['results'],
            'total' => $result['total'],
            'page' => $result['page'],
            'per_page' => $result['per_page'],
            'filters_applied' => $result['filters_applied']
        ), 200);
    }
    
    public function update_relevance($request) {
        $id = max(0, (int)$request->get_param('id'));
        $score = max(0.0, min(100.0, (float)$request->get_param('score')));
        
        $table_check = $this->ensure_table();
        if ($table_check instanceof WP_REST_Response) {
            return $table_check;
        }
        
        $search_service = new Raw_Wire_Search_Service();
        $result = $search_service->update_relevance($id, $score);
        if (is_wp_error($result)) {
            $this->log_error('Update relevance failed', array('id' => $id, 'error' => $result->get_error_message()));
            return new WP_REST_Response(array(
                'success' => false,
                'message' => $result->get_error_message()
            ), 500);
        }
        
        if ($result === false) {
            return new WP_REST_Response(array(
                'success' => false,
                'message' => 'Failed to update relevance score'
            ), 500);
        }
        
        return new WP_REST_Response(array(
            'success' => true,
            'message' => 'Relevance score updated',
            'id' => $id,
            'score' => $score
        ), 200);
    }
    
    public function get_filters($request) {
        $search_service = new Raw_Wire_Search_Service();
        
        global $wpdb;
        $table = $wpdb->prefix . 'rawwire_content';
        $table_check = $this->ensure_table($table);
        if ($table_check instanceof WP_REST_Response) {
            return $table_check;
        }
        
        $statuses = $wpdb->get_col("SELECT DISTINCT status FROM {$table} WHERE status IS NOT NULL");
        $categories = $search_service->get_categories();
        
        return new WP_REST_Response(array(
            'success' => true,
            'filters' => array(
                'statuses' => $statuses,
                'categories' => $categories,
                'date_range' => array(
                    'min' => $wpdb->get_var("SELECT MIN(created_at) FROM {$table}"),
                    'max' => $wpdb->get_var("SELECT MAX(created_at) FROM {$table}")
                )
            )
        ), 200);
    }

    public function clear_cache($request) {
        delete_transient('rawwire_data_cache');
        
        return new WP_REST_Response(array(
            'success' => true,
            'message' => 'Cache cleared successfully'
        ), 200);
    }

    public function get_status($request) {
        $dashboard = Raw_Wire_Dashboard::get_instance();
        $data = $dashboard->get_stored_data();
        $last_sync = get_option('rawwire_last_sync', 'Never');
        
        return new WP_REST_Response(array(
            'success' => true,
            'status' => array(
                'last_sync' => $last_sync,
                'total_items' => count($data),
                'cache_status' => empty($data) ? 'empty' : 'populated',
                'timestamp' => current_time('mysql')
            )
        ), 200);
    }
    
    // Content Management Endpoints
    
    public function get_content($request) {
        global $wpdb;
        $table = $wpdb->prefix . 'rawwire_content';
        $table_check = $this->ensure_table($table);
        if ($table_check instanceof WP_REST_Response) {
            return $table_check;
        }
        
        $status = sanitize_text_field((string)$request->get_param('status'));
        if ($status === '') {
            $status = 'approved';
        }
        $limit = max(1, min(100, (int)$request->get_param('limit')));
        
        $sql = $wpdb->prepare(
            "SELECT * FROM {$table} WHERE status = %s ORDER BY created_at DESC LIMIT %d",
            $status,
            $limit
        );
        
        $content = $wpdb->get_results($sql, ARRAY_A);
        
        return new WP_REST_Response(array(
            'success' => true,
            'count' => count($content),
            'data' => $content,
            'status_filter' => $status
        ), 200);
    }
    
    public function get_single_content($request) {
        global $wpdb;
        $table = $wpdb->prefix . 'rawwire_content';
        $table_check = $this->ensure_table($table);
        if ($table_check instanceof WP_REST_Response) {
            return $table_check;
        }
        
        $id = (int)$request->get_param('id');
        
        $content = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$table} WHERE id = %d",
            $id
        ), ARRAY_A);
        
        if (!$content) {
            return new WP_REST_Response(array(
                'success' => false,
                'message' => 'Content not found'
            ), 404);
        }
        
        return new WP_REST_Response(array(
            'success' => true,
            'data' => $content
        ), 200);
    }
    
    public function approve_content($request) {
        global $wpdb;
        $table = $wpdb->prefix . 'rawwire_content';
        $table_check = $this->ensure_table($table);
        if ($table_check instanceof WP_REST_Response) {
            return $table_check;
        }
        
        $id = (int)$request->get_param('id');
        $user_id = get_current_user_id();
        
        $result = $wpdb->update(
            $table,
            array(
                'status' => 'approved',
                'updated_at' => current_time('mysql')
            ),
            array('id' => $id),
            array('%s', '%s'),
            array('%d')
        );
        
        if ($result === false) {
            $this->log_error('Approve failed', array('id' => $id));
            return new WP_REST_Response(array(
                'success' => false,
                'message' => 'Failed to approve content'
            ), 500);
        }
        if ($result === 0) {
            return new WP_REST_Response(array(
                'success' => false,
                'message' => 'Content not found'
            ), 404);
        }
        
        // Log approval action
        $this->log_action('approve', $id, $user_id);
        
        return new WP_REST_Response(array(
            'success' => true,
            'message' => 'Content approved',
            'id' => $id
        ), 200);
    }
    
    public function reject_content($request) {
        global $wpdb;
        $table = $wpdb->prefix . 'rawwire_content';
        $table_check = $this->ensure_table($table);
        if ($table_check instanceof WP_REST_Response) {
            return $table_check;
        }
        
        $id = (int)$request->get_param('id');
        $user_id = get_current_user_id();
        
        $result = $wpdb->update(
            $table,
            array(
                'status' => 'rejected',
                'updated_at' => current_time('mysql')
            ),
            array('id' => $id),
            array('%s', '%s'),
            array('%d')
        );
        
        if ($result === false) {
            $this->log_error('Reject failed', array('id' => $id));
            return new WP_REST_Response(array(
                'success' => false,
                'message' => 'Failed to reject content'
            ), 500);
        }
        if ($result === 0) {
            return new WP_REST_Response(array(
                'success' => false,
                'message' => 'Content not found'
            ), 404);
        }
        
        // Log rejection action
        $this->log_action('reject', $id, $user_id);
        
        return new WP_REST_Response(array(
            'success' => true,
            'message' => 'Content rejected',
            'id' => $id
        ), 200);
    }
    
    public function bulk_approve($request) {
        global $wpdb;
        $table = $wpdb->prefix . 'rawwire_content';
        $table_check = $this->ensure_table($table);
        if ($table_check instanceof WP_REST_Response) {
            return $table_check;
        }
        
        $ids = array_values(array_filter(array_map('intval', (array)$request->get_param('ids')), function($id) { return $id > 0; }));
        $user_id = get_current_user_id();
        
        if (empty($ids) || !is_array($ids)) {
            return new WP_REST_Response(array(
                'success' => false,
                'message' => 'No IDs provided'
            ), 400);
        }
        
        $placeholders = implode(',', array_fill(0, count($ids), '%d'));
        $result = $wpdb->query($wpdb->prepare(
            "UPDATE {$table} SET status = 'approved', updated_at = %s WHERE id IN ($placeholders)",
            array_merge(array(current_time('mysql')), $ids)
        ));
        if ($result === false) {
            $this->log_error('Bulk approve failed', array('ids' => $ids));
            return new WP_REST_Response(array(
                'success' => false,
                'message' => 'Failed to approve items'
            ), 500);
        }
        
        foreach ($ids as $id) {
            $this->log_action('bulk_approve', $id, $user_id);
        }
        
        return new WP_REST_Response(array(
            'success' => true,
            'message' => "Approved {$result} items",
            'count' => $result
        ), 200);
    }
    
    public function bulk_reject($request) {
        global $wpdb;
        $table = $wpdb->prefix . 'rawwire_content';
        $table_check = $this->ensure_table($table);
        if ($table_check instanceof WP_REST_Response) {
            return $table_check;
        }
        
        $ids = array_values(array_filter(array_map('intval', (array)$request->get_param('ids')), function($id) { return $id > 0; }));
        $user_id = get_current_user_id();
        
        if (empty($ids) || !is_array($ids)) {
            return new WP_REST_Response(array(
                'success' => false,
                'message' => 'No IDs provided'
            ), 400);
        }
        
        $placeholders = implode(',', array_fill(0, count($ids), '%d'));
        $result = $wpdb->query($wpdb->prepare(
            "UPDATE {$table} SET status = 'rejected', updated_at = %s WHERE id IN ($placeholders)",
            array_merge(array(current_time('mysql')), $ids)
        ));
        if ($result === false) {
            $this->log_error('Bulk reject failed', array('ids' => $ids));
            return new WP_REST_Response(array(
                'success' => false,
                'message' => 'Failed to reject items'
            ), 500);
        }
        
        foreach ($ids as $id) {
            $this->log_action('bulk_reject', $id, $user_id);
        }
        
        return new WP_REST_Response(array(
            'success' => true,
            'message' => "Rejected {$result} items",
            'count' => $result
        ), 200);
    }
    
    public function get_stats($request) {
        global $wpdb;
        $table = $wpdb->prefix . 'rawwire_content';
        $table_check = $this->ensure_table($table);
        if ($table_check instanceof WP_REST_Response) {
            return $table_check;
        }
        
        $stats = array(
            'total' => (int)$wpdb->get_var("SELECT COUNT(*) FROM {$table}"),
            'pending' => (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$table} WHERE status = %s", 'pending')),
            'approved' => (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$table} WHERE status = %s", 'approved')),
            'rejected' => (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$table} WHERE status = %s", 'rejected')),
            'last_sync' => get_option('rawwire_last_sync', 'Never'),
            'avg_relevance' => (float)$wpdb->get_var("SELECT AVG(relevance) FROM {$table}"),
            'recent_items' => (int)$wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM {$table} WHERE created_at > %s",
                date('Y-m-d H:i:s', strtotime('-7 days'))
            ))
        );
        
        return new WP_REST_Response(array(
            'success' => true,
            'stats' => $stats,
            'timestamp' => current_time('mysql')
        ), 200);
    }
    
    public function get_logs($request) {
        $limit = min((int)$request->get_param('limit'), 500);
        $severity = $request->get_param('severity');
        
        // For now, return WordPress error log entries related to rawwire
        // In production, you'd have a dedicated logs table
        $logs = array();
        
        if (defined('WP_DEBUG_LOG') && WP_DEBUG_LOG) {
            $log_file = WP_CONTENT_DIR . '/debug.log';
            if (file_exists($log_file)) {
                $lines = file($log_file);
                $count = 0;
                
                foreach (array_reverse($lines) as $line) {
                    if (stripos($line, 'rawwire') !== false || stripos($line, 'raw-wire') !== false || stripos($line, 'raw_wire') !== false) {
                        $logs[] = array(
                            'timestamp' => substr($line, 0, 25),
                            'message' => trim(substr($line, 25)),
                            'severity' => $this->detect_severity($line)
                        );
                        $count++;
                        if ($count >= $limit) break;
                    }
                }
            }
        }
        
        return new WP_REST_Response(array(
            'success' => true,
            'logs' => $logs,
            'count' => count($logs)
        ), 200);
    }
    
    // Helper functions

    private function ensure_table($table = null) {
        if ($table === null) {
            global $wpdb;
            $table = $wpdb->prefix . 'rawwire_content';
        }
        if ($this->table_exists($table)) {
            return null;
        }
        $this->log_error('Missing table', array('table' => $table));
        return new WP_REST_Response(array(
            'success' => false,
            'message' => 'Required data table is missing'
        ), 500);
    }

    private function table_exists($table) {
        global $wpdb;
        return $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $table)) === $table;
    }

    private function log_error($message, $context = array()) {
        $payload = $context ? ' ' . json_encode($context) : '';
        error_log('[RawWire REST] ' . $message . $payload);
    }
    
    private function log_action($action, $content_id, $user_id) {
        // Log to WordPress options or custom table
        $log_entry = array(
            'action' => $action,
            'content_id' => $content_id,
            'user_id' => $user_id,
            'timestamp' => current_time('mysql')
        );
        
        $existing_log = get_option('rawwire_action_log', array());
        $existing_log[] = $log_entry;
        
        // Keep only last 1000 entries
        if (count($existing_log) > 1000) {
            $existing_log = array_slice($existing_log, -1000);
        }
        
        update_option('rawwire_action_log', $existing_log);
    }
    
    private function detect_severity($log_line) {
        $line_lower = strtolower($log_line);
        
        if (strpos($line_lower, 'critical') !== false || strpos($line_lower, 'fatal') !== false) {
            return 'critical';
        } elseif (strpos($line_lower, 'error') !== false) {
            return 'error';
        } elseif (strpos($line_lower, 'warning') !== false || strpos($line_lower, 'warn') !== false) {
            return 'warning';
        } else {
            return 'info';
        }
    }
}

// Initialize REST API
RawWire_REST_API::get_instance();
