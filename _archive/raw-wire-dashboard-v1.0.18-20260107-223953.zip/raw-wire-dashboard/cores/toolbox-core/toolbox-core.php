<?php
/**
 * Toolbox Core - adapter registry and orchestrator hooks
 * Path: cores/toolbox-core/toolbox-core.php
 */
if (! class_exists('RawWire_Toolbox_Core')) {
    class RawWire_Toolbox_Core {
        protected static $adapters = array();

        public static function init() {
            add_action('init', array(__CLASS__, 'register_adapters'));
        }

        public static function register_adapters() {
            // TODO: Discover adapters in cores/toolbox-core/adapters/
            // and register them into self::$adapters
        }

        public static function get_adapter($name) {
            return self::$adapters[$name] ?? null;
        }

        public static function register_adapter_instance($name, $instance) {
            self::$adapters[$name] = $instance;
        }

        // Orchestration entrypoint: accepts a plan and dispatches steps to adapters
        public static function execute_plan(array $plan, callable $on_update = null) {
            // TODO: Implement plan execution, job queueing and callbacks
            if (is_callable($on_update)) {
                call_user_func($on_update, array('status' => 'not_implemented'));
            }
            return false;
        }
    }
}

// Bootstrap
RawWire_Toolbox_Core::init();
