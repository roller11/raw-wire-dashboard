<?php
/**
 * Module Core - module loading and validation
 * Path: cores/module-core/module-core.php
 */
if (! class_exists('RawWire_Module_Core')) {
    class RawWire_Module_Core {
        protected static $active_module = null;

        /**
         * Registered module instances
         * @var array<string, RawWire_Module_Interface>
         */
        protected static $modules = array();

        /**
         * In-memory template config cache
         *
         * @var array|null
         */
        protected static $template_config = null;

        public static function init() {
            add_action('init', array(__CLASS__, 'load_active_module'));
            // Discover modules early so they can register REST/AJAX
            add_action('init', array(__CLASS__, 'discover_modules'), 5);
        }

        public static function load_active_module() {
            // Load active module metadata (if any) into memory
            $module_name = get_option('rawwire_active_module', '');
            if (empty($module_name)) {
                return false;
            }

            $module_json = plugin_dir_path(__FILE__) . "../../modules/{$module_name}/module.json";
            if (! file_exists($module_json)) {
                return false;
            }

            $json = file_get_contents($module_json);
            $config = json_decode($json, true);
            if (is_array($config) && self::validate_module($config)) {
                self::$active_module = $config;
                return true;
            }

            return false;
        }

        /**
         * Discover modules by scanning the `modules/` directory and requiring their bootstrap files.
         * Modules are expected to register themselves by calling `RawWire_Module_Core::register_module()`.
         */
        public static function discover_modules() {
            $modules_dir = plugin_dir_path(__FILE__) . '../../modules';
            if (! is_dir($modules_dir)) {
                return;
            }

            $items = glob(rtrim($modules_dir, '/') . '/*/module.php');
            if (! $items) {
                return;
            }

            foreach ($items as $file) {
                // Require module bootstrap - module should register itself
                try {
                    require_once $file;
                } catch (Exception $e) {
                    // swallow; module load failure should not break admin
                }
            }
        }

        /**
         * Register a module instance so the core can delegate calls.
         * @param string $slug
         * @param RawWire_Module_Interface $instance
         */
        public static function register_module($slug, $instance) {
            if (! is_string($slug) || empty($slug)) {
                return false;
            }
            self::$modules[$slug] = $instance;
            // allow modules to initialize themselves
            if (method_exists($instance, 'init')) {
                try { $instance->init(); } catch (Exception $e) {}
            }
            // Allow module to register REST routes and AJAX handlers
            if (method_exists($instance, 'register_rest_routes')) {
                try { $instance->register_rest_routes(); } catch (Exception $e) {}
            }
            if (method_exists($instance, 'register_ajax_handlers')) {
                try { $instance->register_ajax_handlers(); } catch (Exception $e) {}
            }
            return true;
        }

        /**
         * Get all registered modules
         * @return array<string, RawWire_Module_Interface>
         */
        public static function get_modules() {
            return self::$modules;
        }

        public static function get_active_module() {
            return self::$active_module;
        }

        /**
         * Get the template/module UI config used by the dashboard.
         *
         * Durable behavior:
         * - Prefer module.json if present and valid.
         * - Fallback to the legacy templates/raw-wire-default.json.
         * - Always return an array with safe defaults.
         *
         * @return array
         */
        public static function get_template_config() {
            if (is_array(self::$template_config)) {
                return self::$template_config;
            }

            $fallback = self::get_fallback_template_config();

            // If module config is already loaded and exposes a legacy-compatible template block, prefer it.
            if (is_array(self::$active_module)) {
                // Support either a legacy-compatible shape or a nested `ui.template` shape.
                if (!empty(self::$active_module['template']) && is_array(self::$active_module['template'])) {
                    self::$template_config = array_merge($fallback, self::$active_module['template']);
                    return self::$template_config;
                }
                if (!empty(self::$active_module['ui']['template']) && is_array(self::$active_module['ui']['template'])) {
                    self::$template_config = array_merge($fallback, self::$active_module['ui']['template']);
                    return self::$template_config;
                }
            }

            // Legacy fallback to templates/raw-wire-default.json.
            $legacy = self::load_legacy_template_file();
            if (is_array($legacy)) {
                self::$template_config = array_merge($fallback, $legacy);
                return self::$template_config;
            }

            self::$template_config = $fallback;
            return self::$template_config;
        }

        protected static function load_legacy_template_file() {
            $path = plugin_dir_path(__FILE__) . '../../templates/raw-wire-default.json';
            if (!file_exists($path)) {
                return null;
            }

            $json = file_get_contents($path);
            $data = json_decode($json, true);
            if (is_array($data)) {
                return $data;
            }

            if (class_exists('RawWire_Logger')) {
                RawWire_Logger::log_error(
                    'Failed to decode legacy template JSON',
                    array('path' => $path, 'json_error' => json_last_error_msg()),
                    'warning'
                );
            }

            return null;
        }

        protected static function get_fallback_template_config() {
            return array(
                'name' => 'fallback',
                'theme' => array(
                    'accent' => '#0d9488',
                    'accentBold' => '#0f766e',
                    'surface' => '#0b1724',
                    'card' => '#0f1f33',
                    'muted' => '#8aa0b7',
                ),
                'columns' => array(),
                'badges' => array(),
                'filters' => array(),
            );
        }

        public static function validate_module(array $config) {
            // Minimal validation stub - real validator should use JSON Schema
            if (empty($config['meta']['name'])) {
                return false;
            }
            return true;
        }
    }
}

// Bootstrap
RawWire_Module_Core::init();
