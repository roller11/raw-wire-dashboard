# RawWire Dashboard

A WordPress plugin for managing and curating content findings from various sources.

## Description

RawWire Dashboard provides a clean, standards-compliant interface for managing content findings from multiple sources. It features automatic syncing, content approval workflows, and comprehensive logging.

## Features

- **Standards Compliant**: Follows WordPress coding standards and best practices
- **REST API**: Clean REST API endpoints for data management
- **Admin Dashboard**: Intuitive admin interface with real-time statistics
- **Content Management**: Approve/reject content with status tracking
- **Logging System**: Comprehensive logging with configurable levels
- **Database Optimization**: Efficient database queries and proper indexing

## Installation

1. Upload the `raw-wire-dashboard` folder to `/wp-content/plugins/`
2. Activate the plugin through the WordPress admin
3. Configure settings in the RawWire Dashboard menu

## Plugin Structure

This plugin follows WordPress standards with the following structure:

```
raw-wire-dashboard/
├── assets/
│   ├── css/
│   │   └── admin.css          # Admin styles
│   └── js/
│       └── admin.js           # Admin JavaScript
├── admin/
│   └── class-dashboard.php    # Admin dashboard class
├── includes/
│   ├── class-admin.php        # Admin functionality
│   ├── class-logger.php       # Logging system
│   └── class-rest-api.php     # REST API endpoints
├── languages/                 # Translation files
├── templates/                 # Template files (future use)
├── raw-wire-dashboard.php     # Main plugin file
├── uninstall.php              # Clean uninstallation
└── README.md                  # This file
```

## Standards Compliance

This plugin adheres to WordPress coding standards:

- **Class Naming**: Classes use `RawWire_` prefix
- **File Naming**: Files use `class-` prefix for class files
- **Hooks**: Proper use of WordPress action/filter hooks
- **Security**: Nonces, capability checks, and data sanitization
- **Database**: Proper table creation and data handling
- **Localization**: Ready for translation with text domains
- **Uninstallation**: Clean uninstall with `uninstall.php`

## API Endpoints

### REST API

- `GET /wp-json/rawwire/v1/content` - Get content items
- `PUT /wp-json/rawwire/v1/content/{id}` - Update content status
- `POST /wp-json/rawwire/v1/sync` - Trigger data sync
- `GET /wp-json/rawwire/v1/stats` - Get dashboard statistics

### AJAX Endpoints

- `rawwire_sync` - Sync data
- `rawwire_update_content` - Update content status

## Database Tables

- `{prefix}rawwire_content` - Content items
- `{prefix}rawwire_logs` - Activity logs

## Hooks

### Actions

- `rawwire_content_synced` - Fired after content sync
- `rawwire_content_updated` - Fired after content status update

### Filters

- `rawwire_sync_sources` - Filter available sync sources
- `rawwire_content_query` - Filter content queries

## Changelog

### 1.0.18
- Complete restructure to follow WordPress standards
- Simplified architecture with proper separation of concerns
- Standards-compliant class naming and file organization
- Clean REST API implementation
- Improved admin interface with modern CSS
- Added comprehensive logging system
- Proper uninstallation support

## Contributing

Please follow WordPress coding standards when contributing to this plugin.

## License

GPL v2 or later
```
GET  /wp-json/rawwire/v1/content
POST /wp-json/rawwire/v1/content/approve
POST /wp-json/rawwire/v1/content/snooze
POST /wp-json/rawwire/v1/fetch-data
POST /wp-json/rawwire/v1/clear-cache
GET  /wp-json/rawwire/v1/stats
```

## Styling + Modularity

The dashboard UI is template-driven and themeable.

- The dashboard wrapper includes `data-rawwire-template="..."` so templates can apply targeted overrides.
- Template config may provide a `theme` block; the plugin maps supported keys into CSS variables on the dashboard container:
  - `accent`, `accentBold`, `surface`, `card`, `muted`

## Testing

Functional suite (always runnable):

```bash
composer test:functional
```

PHPUnit (requires WordPress test suite + a DB):

```bash
# Install WordPress develop checkout + phpunit test lib to /tmp
./tools/install-wp-test-env.sh

# Install dev deps (phpunit)
composer install

# Run PHPUnit
composer test:phpunit
```

## Architecture

### Modular Components
- `includes/` - Core classes
- `search-modules/` - Pluggable filters
- `api/` - REST API controllers
- `assets/` - JavaScript & CSS
- `templates/` - UI views

### Database Tables
- `wp_rawwire_content` - Content items
- `wp_rawwire_logs` - Activity logs
- `wp_rawwire_api_keys` - API authentication

## Implementation Status

### Completed
- [x] Comprehensive specifications
- [x] Plugin structure
- [x] Documentation
- [x] Copilot integration guide

### In Progress
- [ ] Database schema implementation
- [ ] GitHub data fetcher
- [ ] Approval workflow
- [ ] Modular search system
- [ ] Enhanced UI

## For GitHub Copilot

This codebase is optimized for GitHub Copilot:

1. **Complete Context**: All specifications in DASHBOARD_SPEC.md
2. **Clear Instructions**: Step-by-step guide in COPILOT_INSTRUCTIONS.md
3. **Code Examples**: Reference implementations included
4. **Standards**: WordPress coding conventions enforced

### Using with Copilot

```
# In your IDE with Copilot enabled:
1. Open DASHBOARD_SPEC.md for full context
2. Open COPILOT_INSTRUCTIONS.md for implementation guide
3. Start coding - Copilot will suggest based on specifications
4. Reference specifications in comments for better suggestions
```

## Security

- Nonce verification on all forms
- Capability checks (manage_options)
- Input sanitization
- Output escaping
- Prepared SQL statements
- API authentication
- Rate limiting

## Performance

- Dashboard load: < 2s
- API response: < 500ms
- Database optimization
- Transient caching
- Lazy loading
- Minified assets

## Integration

### AI Content Models
```javascript
fetch('/wp-json/rawwire/v1/content?status=approved', {
  headers: {'Authorization': 'Bearer API_KEY'}
})
.then(res => res.json())
.then(data => generatePosts(data));
```

### Social Media Automation
- Zapier webhooks
- n8n workflows
- Direct API integration

## Support

- Architecture: DASHBOARD_SPEC.md
- Implementation: COPILOT_INSTRUCTIONS.md
- API: REST_API_GUIDE.md

## License
Proprietary - Raw-Wire DAO LLC

## Version
1.0.13
