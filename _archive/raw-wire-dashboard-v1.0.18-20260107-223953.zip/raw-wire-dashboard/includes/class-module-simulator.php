<?php
/**
 * RawWire Module Simulator
 *
 * Simulates module behavior for dashboard testing without requiring actual modules.
 * Implements the RawWire_Module_Interface to provide mock data and functionality.
 *
 * @package RawWire_Dashboard
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

// Ensure interface is loaded
require_once plugin_dir_path(__FILE__) . 'interface-module.php';

/**
 * RawWire Module Simulator Class
 *
 * Provides mock data and simulates module functionality for testing the dashboard
 * without requiring actual external modules to be installed.
 */
class RawWire_Module_Simulator implements RawWire_Module_Interface {

    /**
     * Module metadata
     */
    private $metadata = array(
        'name' => 'RawWire Module Simulator',
        'slug' => 'module-simulator',
        'version' => '1.0.0',
        'description' => 'Simulates module behavior for dashboard testing'
    );

    /**
     * Mock data for different panel types
     */
    private $mock_data = array();

    /**
     * Initialize the simulator module
     */
    public function init() {
        // Generate mock data on initialization
        $this->generate_mock_data();

        // Hook into WordPress
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_scripts'));
    }

    /**
     * Register REST API routes
     */
    public function register_rest_routes() {
        register_rest_route('rawwire/v1', '/simulator/data', array(
            'methods' => 'GET',
            'callback' => array($this, 'handle_rest_data_request'),
            'permission_callback' => array($this, 'check_permissions')
        ));

        register_rest_route('rawwire/v1', '/simulator/panels', array(
            'methods' => 'GET',
            'callback' => array($this, 'handle_rest_panels_request'),
            'permission_callback' => array($this, 'check_permissions')
        ));
    }

    /**
     * Register AJAX handlers
     */
    public function register_ajax_handlers() {
        add_action('wp_ajax_rawwire_simulator_fetch', array($this, 'handle_ajax_fetch'));
        add_action('wp_ajax_rawwire_simulator_render_panel', array($this, 'handle_ajax_render_panel'));
    }

    /**
     * Get admin panels configuration
     */
    public function get_admin_panels() {
        return array(
            'main-dashboard' => array(
                'id' => 'main-dashboard',
                'title' => 'Research Dashboard',
                'type' => 'data-table',
                'description' => 'Main research findings dashboard with filtering and approval workflow',
                'columns' => array(
                    array('key' => 'rank', 'label' => 'Rank', 'width' => '64px'),
                    array('key' => 'title', 'label' => 'Finding'),
                    array('key' => 'source', 'label' => 'Source', 'width' => '120px'),
                    array('key' => 'category', 'label' => 'Category', 'width' => '140px'),
                    array('key' => 'score', 'label' => 'Score', 'width' => '90px'),
                    array('key' => 'freshness', 'label' => 'Freshness', 'width' => '120px'),
                    array('key' => 'status', 'label' => 'Status', 'width' => '110px')
                ),
                'actions' => array(
                    'approve' => array('label' => 'Approve', 'action' => 'approve_item'),
                    'reject' => array('label' => 'Reject', 'action' => 'reject_item'),
                    'view' => array('label' => 'View Details', 'action' => 'view_item')
                )
            ),
            'analytics-panel' => array(
                'id' => 'analytics-panel',
                'title' => 'Analytics Overview',
                'type' => 'chart',
                'description' => 'Key metrics and analytics visualization',
                'chart_type' => 'bar',
                'data_source' => 'analytics'
            ),
            'recent-activity' => array(
                'id' => 'recent-activity',
                'title' => 'Recent Activity',
                'type' => 'activity-feed',
                'description' => 'Recent system activity and user actions'
            ),
            'settings-panel' => array(
                'id' => 'settings-panel',
                'title' => 'Module Settings',
                'type' => 'settings',
                'description' => 'Configure simulator settings and preferences'
            )
        );
    }

    /**
     * Get module metadata
     */
    public function get_metadata() {
        return $this->metadata;
    }

    /**
     * Handle REST API requests
     */
    public function handle_rest_request($action, $request) {
        switch ($action) {
            case 'data':
                return $this->handle_rest_data_request($request);
            case 'panels':
                return $this->handle_rest_panels_request($request);
            default:
                return new WP_REST_Response(array(
                    'success' => false,
                    'message' => 'Unknown action: ' . $action
                ), 400);
        }
    }

    /**
     * Handle AJAX requests
     */
    public function handle_ajax($action, $data) {
        switch ($action) {
            case 'fetch':
                return $this->handle_ajax_fetch();
            case 'render_panel':
                return $this->handle_ajax_render_panel($data);
            default:
                return array('success' => false, 'message' => 'Unknown action: ' . $action);
        }
    }

    /**
     * Generate mock data for testing
     */
    private function generate_mock_data() {
        $this->mock_data = array(
            'research_findings' => array(
                array(
                    'id' => 1,
                    'rank' => 1,
                    'title' => 'New SEC Filing Reveals Market Strategy',
                    'source' => 'sec',
                    'category' => 'regulatory',
                    'score' => 95,
                    'freshness' => '2 hours ago',
                    'status' => 'pending'
                ),
                array(
                    'id' => 2,
                    'rank' => 2,
                    'title' => 'GitHub Repository Shows AI Advancement',
                    'source' => 'github',
                    'category' => 'technical',
                    'score' => 87,
                    'freshness' => '4 hours ago',
                    'status' => 'approved'
                ),
                array(
                    'id' => 3,
                    'rank' => 3,
                    'title' => 'Market Analysis: Q4 Trends',
                    'source' => 'news',
                    'category' => 'market',
                    'score' => 78,
                    'freshness' => '6 hours ago',
                    'status' => 'processing'
                ),
                array(
                    'id' => 4,
                    'rank' => 4,
                    'title' => 'Risk Assessment Update',
                    'source' => 'sec',
                    'category' => 'risk',
                    'score' => 82,
                    'freshness' => '8 hours ago',
                    'status' => 'pending'
                ),
                array(
                    'id' => 5,
                    'rank' => 5,
                    'title' => 'Technical Documentation Released',
                    'source' => 'github',
                    'category' => 'technical',
                    'score' => 91,
                    'freshness' => '12 hours ago',
                    'status' => 'approved'
                )
            ),
            'analytics' => array(
                'total_findings' => 1247,
                'approved_today' => 23,
                'pending_review' => 45,
                'avg_score' => 84.5,
                'sources_breakdown' => array(
                    'github' => 45,
                    'sec' => 30,
                    'news' => 25
                )
            ),
            'activity' => array(
                array(
                    'timestamp' => '2024-01-15 14:30:00',
                    'action' => 'approved',
                    'user' => 'admin',
                    'item' => 'SEC Filing Analysis'
                ),
                array(
                    'timestamp' => '2024-01-15 14:25:00',
                    'action' => 'rejected',
                    'user' => 'admin',
                    'item' => 'Outdated Market Data'
                ),
                array(
                    'timestamp' => '2024-01-15 14:20:00',
                    'action' => 'processed',
                    'user' => 'system',
                    'item' => 'GitHub Repository Scan'
                )
            )
        );
    }

    /**
     * Handle REST data requests
     */
    public function handle_rest_data_request($request) {
        $type = $request->get_param('type') ?: 'research_findings';

        if (!isset($this->mock_data[$type])) {
            return new WP_REST_Response(array(
                'success' => false,
                'message' => 'Unknown data type: ' . $type
            ), 400);
        }

        return new WP_REST_Response(array(
            'success' => true,
            'data' => $this->mock_data[$type],
            'timestamp' => current_time('mysql')
        ));
    }

    /**
     * Handle REST panels requests
     */
    public function handle_rest_panels_request($request) {
        return new WP_REST_Response(array(
            'success' => true,
            'panels' => $this->get_admin_panels()
        ));
    }

    /**
     * Handle AJAX fetch requests
     */
    public function handle_ajax_fetch() {
        check_ajax_referer('rawwire_ajax_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_die('Insufficient permissions');
        }

        $type = sanitize_text_field($_POST['type'] ?? 'research_findings');

        if (!isset($this->mock_data[$type])) {
            wp_send_json_error('Unknown data type: ' . $type);
        }

        wp_send_json_success(array(
            'data' => $this->mock_data[$type],
            'timestamp' => current_time('mysql')
        ));
    }

    /**
     * Handle AJAX render panel requests
     */
    public function handle_ajax_render_panel($data) {
        check_ajax_referer('rawwire_ajax_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_die('Insufficient permissions');
        }

        $panel_id = sanitize_text_field($data['panel_id'] ?? '');

        if (empty($panel_id)) {
            wp_send_json_error('Panel ID required');
        }

        $panels = $this->get_admin_panels();

        if (!isset($panels[$panel_id])) {
            wp_send_json_error('Unknown panel: ' . $panel_id);
        }

        $panel = $panels[$panel_id];
        $html = $this->render_panel_html($panel);

        wp_send_json_success(array(
            'html' => $html,
            'panel' => $panel
        ));
    }

    /**
     * Render panel HTML
     */
    private function render_panel_html($panel) {
        ob_start();

        switch ($panel['type']) {
            case 'data-table':
                $this->render_data_table($panel);
                break;
            case 'chart':
                $this->render_chart($panel);
                break;
            case 'activity-feed':
                $this->render_activity_feed($panel);
                break;
            case 'settings':
                $this->render_settings($panel);
                break;
            default:
                echo '<div class="rawwire-panel"><p>Panel type not implemented: ' . esc_html($panel['type']) . '</p></div>';
        }

        return ob_get_clean();
    }

    /**
     * Render data table panel
     */
    private function render_data_table($panel) {
        ?>
        <div class="rawwire-panel rawwire-data-table-panel">
            <div class="panel-header">
                <h3><?php echo esc_html($panel['title']); ?></h3>
                <p><?php echo esc_html($panel['description']); ?></p>
            </div>
            <div class="panel-content">
                <table class="rawwire-data-table">
                    <thead>
                        <tr>
                            <?php foreach ($panel['columns'] as $column): ?>
                                <th style="width: <?php echo esc_attr($column['width'] ?? 'auto'); ?>">
                                    <?php echo esc_html($column['label']); ?>
                                </th>
                            <?php endforeach; ?>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($this->mock_data['research_findings'] as $item): ?>
                            <tr>
                                <?php foreach ($panel['columns'] as $column): ?>
                                    <td><?php echo esc_html($item[$column['key']] ?? ''); ?></td>
                                <?php endforeach; ?>
                                <td>
                                    <button class="button button-small approve-btn" data-id="<?php echo esc_attr($item['id']); ?>">Approve</button>
                                    <button class="button button-small reject-btn" data-id="<?php echo esc_attr($item['id']); ?>">Reject</button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php
    }

    /**
     * Render chart panel
     */
    private function render_chart($panel) {
        ?>
        <div class="rawwire-panel rawwire-chart-panel">
            <div class="panel-header">
                <h3><?php echo esc_html($panel['title']); ?></h3>
                <p><?php echo esc_html($panel['description']); ?></p>
            </div>
            <div class="panel-content">
                <div class="analytics-grid">
                    <div class="metric-card">
                        <h4>Total Findings</h4>
                        <div class="metric-value"><?php echo number_format($this->mock_data['analytics']['total_findings']); ?></div>
                    </div>
                    <div class="metric-card">
                        <h4>Approved Today</h4>
                        <div class="metric-value"><?php echo $this->mock_data['analytics']['approved_today']; ?></div>
                    </div>
                    <div class="metric-card">
                        <h4>Pending Review</h4>
                        <div class="metric-value"><?php echo $this->mock_data['analytics']['pending_review']; ?></div>
                    </div>
                    <div class="metric-card">
                        <h4>Average Score</h4>
                        <div class="metric-value"><?php echo $this->mock_data['analytics']['avg_score']; ?>%</div>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }

    /**
     * Render activity feed panel
     */
    private function render_activity_feed($panel) {
        ?>
        <div class="rawwire-panel rawwire-activity-panel">
            <div class="panel-header">
                <h3><?php echo esc_html($panel['title']); ?></h3>
                <p><?php echo esc_html($panel['description']); ?></p>
            </div>
            <div class="panel-content">
                <div class="activity-feed">
                    <?php foreach ($this->mock_data['activity'] as $activity): ?>
                        <div class="activity-item">
                            <div class="activity-timestamp"><?php echo esc_html($activity['timestamp']); ?></div>
                            <div class="activity-content">
                                <strong><?php echo esc_html($activity['user']); ?></strong>
                                <?php echo esc_html($activity['action']); ?>
                                <em><?php echo esc_html($activity['item']); ?></em>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
        <?php
    }

    /**
     * Render settings panel
     */
    private function render_settings($panel) {
        ?>
        <div class="rawwire-panel rawwire-settings-panel">
            <div class="panel-header">
                <h3><?php echo esc_html($panel['title']); ?></h3>
                <p><?php echo esc_html($panel['description']); ?></p>
            </div>
            <div class="panel-content">
                <form class="rawwire-settings-form">
                    <div class="form-group">
                        <label for="simulator_enabled">Enable Simulator</label>
                        <input type="checkbox" id="simulator_enabled" name="simulator_enabled" checked>
                    </div>
                    <div class="form-group">
                        <label for="mock_data_count">Mock Data Items</label>
                        <input type="number" id="mock_data_count" name="mock_data_count" value="5" min="1" max="100">
                    </div>
                    <div class="form-group">
                        <label for="refresh_interval">Refresh Interval (seconds)</label>
                        <input type="number" id="refresh_interval" name="refresh_interval" value="30" min="5" max="300">
                    </div>
                    <button type="submit" class="button button-primary">Save Settings</button>
                </form>
            </div>
        </div>
        <?php
    }

    /**
     * Enqueue scripts and styles
     */
    public function enqueue_scripts() {
        wp_enqueue_style('rawwire-simulator', plugins_url('css/simulator.css', __FILE__), array(), $this->metadata['version']);
        wp_enqueue_script('rawwire-simulator', plugins_url('js/simulator.js', __FILE__), array('jquery'), $this->metadata['version'], true);

        wp_localize_script('rawwire-simulator', 'rawwireSimulator', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('rawwire_ajax_nonce'),
            'strings' => array(
                'loading' => 'Loading...',
                'error' => 'An error occurred',
                'success' => 'Success'
            )
        ));
    }

    /**
     * Check REST API permissions
     */
    public function check_permissions() {
        return current_user_can('manage_options');
    }
}